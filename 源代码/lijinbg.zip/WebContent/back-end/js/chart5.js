/**
 * 
 */
var myChart = echarts.init(document.getElementById('chart5'));
var option = {
	    title: {
	        text: '平台盈利状况',
            x:'center',
            textStyle:{'fontSize':24},
	    },
	    tooltip: {
	        trigger: 'axis'
	    },
	    legend: {
            orient: 'vertical',
            x: 'right',
	        data:['企业','投资者']
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        bottom: '10%',
	        containLabel: true
	    },

	    xAxis: {
	        type: 'category',
	        boundaryGap: false,
	        data: ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月']
	    },
	    yAxis: {
	        type: 'value',
	        name: '金额（万元）',
	        min:  '10'
	     
	    },
	    series: [
	        {
	            name:'企业',
	            type:'line',
	            data:[20, 32, 10, 34, 20, 30, 10,15, 23, 20, 54, 19]
	        },
	        {
	            name:'投资者',
	            type:'line',
	            data:[22, 12, 19, 34, 29, 33, 10,21,23,13,24,25]
	        },
	       
	    ]
	};

myChart.setOption(option);