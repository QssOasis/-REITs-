
function ShowLoginBox()
{
	layer.open({
		type:1,
		title:"修改密码",
		area:["325px","350px"],
		offset: '150px',
		content:$("#loginbox")
		});			
}

function Login()
{
	var oldloginpass=$.trim($("#oldloginpass").val());
	var newloginpass=$.trim($("#newloginpass").val());
	if(oldloginpass==''||newloginpass==''){
		layer.alert("密码不能为空",{title:"提示"});
	}
	else{
		$.post("/Handler1.ashx",{"oldloginpass":oldloginpass,"newloginpass":newloginpass},function(data){});	
	}
}

function ShowPayBox()
{
	layer.open({
		type:1,
		title:"修改密码",
		area:["325px","350px"],
		offset: '150px',
		content:$("#paybox")
		});			
}


function Pay()
{
	var oldpaypass=$.trim($("#oldpaypass").val());
	var newpaypass=$.trim($("#newpaypass").val());
	if(oldpaypass==''||newpaypass==''){
		layer.alert("密码不能为空",{title:"提示"});
	}
	else{
		$.post("/Handler1.ashx",{"oldpaypass":oldpaypass,"newpaypass":newpaypass},function(data){});	
	}
}

function ShowTelBox()
{
	layer.open({
		type:1,
		title:"修改密码",
		area:["325px","350px"],
		offset: '150px',
		content:$("#telbox")
		});			
}

function Tel()
{
	var oldtel=$.trim($("#oldtel").val());
	var newtel=$.trim($("#newtel").val());
	if(oldtel==''||newtel==''){
		layer.alert("手机号码不能为空",{title:"提示"});
	}
	else{
		$.post("/Handler1.ashx",{"oldtel":oldpaypass,"newtel":newpaypass},function(data){});	
	}
}