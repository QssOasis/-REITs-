
                var myChart = echarts.init(document.getElementById('hoop2'));


                var option = {
                        app:{title: '嵌套环形图'},
                    title : {
                                text: '2016年7月份资产池情况',
                                x:'center',
                                textStyle:{'fontSize':25},

                            },
                    tooltip: {
                        trigger: 'item',
                        formatter: "{a} <br/>{b}: {c} ({d}%)"
                    },
                    legend: {
                        orient: 'vertical',
                        x: 'left',
                        data:['金融投资','旅游酒店','电子通信','化学化工','交通运输','电气设备','建筑建材','其他','家居日用','生物医药',]
                    },
                    series: [
                        {
                            name:'访问来源',
                            type:'pie',
                            selectedMode: 'single',
                            radius: [0, '35%'],

                            label: {
                                normal: {
                                    position: 'inner'
                                }
                            },
                            labelLine: {
                                normal: {
                                    show: false
                                }
                            },
                            data:[
                                             {value: 32.50, name:'应收账款'},
                                             {value: 5.00,  name:'收费收益权'},
                                             {value: 5.00,  name:'住房公积金'},
                                             {value: 17.50,  name:'信托收益权'},
                                             {value: 22.50,  name:'商业票据'},
                                             {value: 17.50  , name:'其他'},
                            ]
                        },
                        {
                            name:'访问来源',
                            type:'pie',
                            radius: ['45%', '60%'],

                            data:[
                                    {value:10.64, name:'金融投资'},
                                    {value:10.64, name:'其他'},
                                    {value:8.51, name:'电子通信'},
                                    {value:2.13, name:'化学化工'},
                                    {value:12.77, name:'交通运输'},
                                    {value:14.89, name:'电气设备'},
                                    {value:8.51, name:'建筑建材'},
                                    {value:8.51, name:'旅游酒店'},
                                    {value:6.38, name:'家居日用'},
                                    {value:17.02, name:'生物医药'},
                                ],
                        }
                    ]
                };
                myChart.setOption(option);