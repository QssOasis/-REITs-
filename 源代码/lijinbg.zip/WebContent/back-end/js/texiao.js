/* sidebar */
function f(str){
                var sub_menu = document.getElementById(str);
                var dis_v = sub_menu.style.display;
                
                if(dis_v == "none")
                    sub_menu.style.display = "block";
                else
                    sub_menu.style.display = "none";
                    
            }
/* sidebar */

/* switch div1 */
function showhidediv(id){    
var hour=document.getElementById("msg_1");
var day=document.getElementById("msg_2");    
var week=document.getElementById("msg_3");
var month=document.getElementById("msg_4");    
var end=document.getElementById("msg_5");

switch(id)
    {
        case "hour":
            if(hour.style.display=='none'){
                hour.style.display='block';
                hour.className='active';
                day.style.display='none';
                week.style.display='none';
                month.style.display='none';
                end.style.display='none';
            }
            break;
        case "day":
            if(day.style.display=='none'){
                day.style.display='block'; 
                day.className='active';
                hour.style.display='none';
                week.style.display='none';
                month.style.display='none';
                end.style.display='none';
            }
            break;
        case "week":
            if(week.style.display=='none'){
                week.style.display='block'; 
                week.className='active';
                hour.style.display='none';
                day.style.display='none';
                month.style.display='none';
                end.style.display='none';
            }
            break;
        case "month":
            if(month.style.display=='none'){
                month.style.display='block'; 
                month.className='active';
                day.style.display='none';
                week.style.display='none';
                hour.style.display='none';
                end.style.display='none';
            }
            break;
        case "end":
            if(end.style.display=='none'){
                end.style.display='block'; 
                end.className='active';
                day.style.display='none';
                week.style.display='none';
                month.style.display='none';
                hour.style.display='none';
            }
            break;
    }
     
}  
/* switch div1 */


/* switch div2 */
function showdiv(id){    
var div1=document.getElementById("today");
var div2=document.getElementById("history");    
var div3=document.getElementById("soldOut");


switch(id)
    {
        case "div1":
            if(div1.style.display=='none'){
                div1.style.display='block';
                div2.style.display='none';
                div3.style.display='none';
            }
            break;
         case "div2":
            if(div2.style.display=='none'){
                div2.style.display='block';
                div1.style.display='none';
                div3.style.display='none';
            }
            break;
         case "div3":
            if(div3.style.display=='none'){
                div3.style.display='block';
                div2.style.display='none';
                div1.style.display='none';
            }
            break;
    }
     
}  
/* switch div2 */

/* mask-alert */
$(document).ready(function(){
	   //买入
	   $("#buy-config").iziModal({
	        title: "系统提示",
	        subtitle: "",
	        iconClass: 'icon-announcement',
	        width: 700,
	        padding: 20,
	        headerColor:"#f8971d",
	       
	    });
	    $(document).on('click', '#btnConfirm1', function (event) {
	        event.preventDefault();
	        $('#buy-config').iziModal('open');
	    });
	    $("#buy-sure").bind("click",function(){
	    	$('#buy-config').iziModal('close');
	    	//传值
		    })
	    $("#buy-cancel").bind("click",function(){
	    	$('#buy-config').iziModal('close');
		    })
			
		$("#buy-reset").iziModal({
		        title: "系统提示",
		        subtitle: "",
		        iconClass: 'icon-announcement',
		        width: 700,
		        padding: 20,
				headerColor:"#f8971d",
		    });
		    $(document).on('click', '#btnReset1', function (event) {
		        event.preventDefault();
		        $('#buy-reset').iziModal('open');
		    });
		    $("#buy-resetsure").bind("click",function(){
		    	$('#buy-reset').iziModal('close');
		    	//传值
			    })
		    $("#buy-resetcancel").bind("click",function(){
		    	$('#buy-reset').iziModal('close');
			    })


			    //卖出
				   $("#sell-config").iziModal({
				        title: "系统提示",
				        subtitle: "",
				        iconClass: 'icon-announcement',
				        width: 700,
				        padding: 20,
						headerColor:"#f8971d",
				    });
				    $(document).on('click', '#btnConfirm2', function (event) {
				        event.preventDefault();
				        $('#sell-config').iziModal('open');
				    });
				    $("#sell-sure").bind("click",function(){
				    	$('#sell-config').iziModal('close');
				    	//传值
					    })
				    $("#sell-cancel").bind("click",function(){
				    	$('#sell-config').iziModal('close');
					    })
						
					$("#sell-reset").iziModal({
					        title: "系统提示",
					        subtitle: "",
					        iconClass: 'icon-announcement',
					        width: 700,
					        padding: 20,
							headerColor:"#f8971d",
					    });
					    $(document).on('click', '#btnReset2', function (event) {
					        event.preventDefault();
					        $('#sell-reset').iziModal('open');
					    });
					    $("#sell-resetsure").bind("click",function(){
					    	$('#sell-reset').iziModal('close');
					    	//传值
						    })
					    $("#sell-resetcancel").bind("click",function(){
					    	$('#sell-reset').iziModal('close');
						    })
						    //撤单
						    $("#revoke-config").iziModal({
						        title: "系统提示",
						        subtitle: "",
						        iconClass: 'icon-announcement',
						        width: 700,
						        padding: 20,
								headerColor:"#f8971d",
						    });
						    $(document).on('click', '#revoke', function (event) {
						        event.preventDefault();
						        $('#revoke-config').iziModal('open');
						    });
						    $("#revoke-sure").bind("click",function(){
						    	$('#revoke-config').iziModal('close');
						    	//传值
							    })
						    $("#revoke-cancel").bind("click",function(){
						    	$('#revoke-config').iziModal('close');
							    })
	//充值													    
      $("#recharge-config").iziModal({
						        title: "系统提示",
						        subtitle: "",
						        iconClass: 'icon-announcement',
						        width: 700,
						        padding: 20,
								headerColor:"#d51926",
						    });
						    $(document).on('click', '#btnTrans1', function (event) {
						        event.preventDefault();
						        $('#recharge-config').iziModal('open');
						    });
						    $("#recharge-sure").bind("click",function(){
						    	$('#recharge-config').iziModal('close');
						    	//传值
							    })
						    $("#recharge-cancel").bind("click",function(){
						    	$('#recharge-config').iziModal('close');
							    })
								
	//批量撤单
 	$("#revokeall-config").iziModal({
						        title: "系统提示",
						        subtitle: "",
						        iconClass: 'icon-announcement',
						        width: 700,
						        padding: 20,
								headerColor:"#d51926",
						    });
						    $(document).on('click', '#revoke-all', function (event) {
						        event.preventDefault();
						        $('#revokeall-config').iziModal('open');
						    });
						    $("#revokeall-sure").bind("click",function(){
						    	$('#revokeall-config').iziModal('close');
								})

	//提现
						    $("#withdraw-config").iziModal({
						        title: "系统提示",
						        subtitle: "",
						        iconClass: 'icon-announcement',
						        width: 700,
						        padding: 20,
								headerColor:"#d51926",
						    });
						    $(document).on('click', '#btnTrans2', function (event) {
						        event.preventDefault();
						        $('#withdraw-config').iziModal('open');
						    });
						    $("#withdraw-sure").bind("click",function(){
						    	$('#withdraw-config').iziModal('close');
						    	//传值
							    })
						    $("#withdraw-cancel").bind("click",function(){
						    	$('#withdraw-config').iziModal('close');
							    })
								
	//添加银行卡
	 $("#addbankcard").iziModal({
	        title: "系统提醒",	        
	        iconClass: 'icon-announcement',
	        width: 500,
	        padding: 20,
			headerColor:"#d51926",
	    });
	    $(document).on('click', '#btn_basicInfoUpdate', function (event) {
	        event.preventDefault();
	        $('#addbankcard').iziModal('open');
	    });
	    $("#addbc-sure").bind("click",function(){
	    	$("#addbankcard").iziModal('close');
	    	//传值
	        })
	    $("#addbc-cancel").bind("click",function(){
	    	$("#addbankcard").iziModal('close');
	    })
		
		//消息盒子
		$("#client-alert").iziModal({
	        title: "消息盒子",
	        iconClass: 'icon-announcement',
	        width: 700,
	        padding: 20,
			headerColor:"#d51926",
	    });
	    $(document).on('click', '.clientAlert', function (event) {
	        event.preventDefault();
	        $('#client-alert').iziModal('open');
	        $(this).next().removeClass("");
	        $(this).next().addClass("");
	    });
		$("#addbc-cancel").bind("click",function(){
	    	$("#client-alert").iziModal('close');
	    })
        
        //批量撤单
 	$("#check-config").iziModal({
						        title: "系统提示",
						        subtitle: "",
						        iconClass: 'icon-announcement',
						        width: 700,
						        padding: 20,
								headerColor:"#f8971d",
						    });
						    $(document).on('click', '#check', function (event) {
						        event.preventDefault();
						        $('#check-config').iziModal('open');
						    });
						    $("#check-sure").bind("click",function(){
						    	$('#check-config').iziModal('close');
								})
                            $("#check-cancel").bind("click",function(){
						    	$('#check-config').iziModal('close');
								})

        

})




