/**
 * 
 */
 var myChart = echarts.init(document.getElementById('chart14'));
                var option = {
                         title : {
                                text: '每月申请融资企业数量',
                                textStyle:{'fontSize':20},
                                x:'center'

                            },
                            tooltip : {
                                trigger: 'axis'
                            },

                            calculable : true,
                            xAxis : [
                                {
                                    type : 'category',
                                    boundaryGap : false,
                                    data : ["2015.07","2015.08","2015.09","2015.10","2015.11","2015.12","2016.01","2016.02","2016.03","2016.04","2016.05","2016.06"]
                                }
                            ],
                            yAxis : [
                                {
                                    type : 'value',
                                    axisLabel : {
                                        formatter: '{value} 个'
                                    }
                                }
                            ],
                            series : [
                                {

                                    type:'line',
                                    data:[1, 2, 3, 4, 2, 3, 5, 4, 4, 4, 6, 6],

                                    markLine : {
                                        data : [
                                            {type : 'average', name: '平均值'}
                                        ]
                                    }
                                }]
                };
myChart.setOption(option);