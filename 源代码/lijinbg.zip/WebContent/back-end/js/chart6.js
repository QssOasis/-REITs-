/**
 * 
 */
var myChart = echarts.init(document.getElementById('chart6'));
var option = {
	    title: {
	        text: '风险状况',
            x:'center',
            textStyle:{'fontSize':24},
	    },
	    tooltip: {
	        trigger: 'axis'
	    },
	    legend: {
            orient: 'vertical',
            x: 'right',
	        data:['违约率','提前偿付率']
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        bottom: '10%',
	        containLabel: true
	    },
	   
	    xAxis: {
	        type: 'category',
	        boundaryGap: false,
	        data: ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月']
	    },
	    yAxis: {
	        type: 'value',
	        name: '比率(%)',
	     
	    },
	    series: [
	        {
	            name:'违约率',
	            type:'line',
	            data:[0.24,0.73,0.31,0.19,0.35,0.46,0.22,0.55,0.87,0.31,0.24,0.74]
	        },
	        {
	            name:'提前偿付率',
	            type:'line',
	            data:[0.35, 0.65, 0.78, 0.37, 0.21, 0.48, 0.55,0.78,0.69,0.95,0.35,0.56]
	        },
	       
	    ]
	};

myChart.setOption(option);