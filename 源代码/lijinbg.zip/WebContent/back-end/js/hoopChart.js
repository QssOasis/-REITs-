
                var myChart = echarts.init(document.getElementById('hoop'));


                var option = {
                        app:{title: '嵌套环形图'},
                    title : {
                                text: '资产池情况',
                                x:'center',
                                textStyle:{'fontSize':25},

                            },
                    tooltip: {
                        trigger: 'item',
                        formatter: "{a} <br/>{b}: {c} ({d}%)"
                    },
                    legend: {
                        orient: 'vertical',
                        x: 'left',
                        data:['金融投资','旅游酒店','电子通信','化学化工','交通运输','电气设备','建筑建材','其他','家居日用','生物医药',]
                    },
                    series: [
                        {
                            name:'访问来源',
                            type:'pie',
                            selectedMode: 'single',
                            radius: [0, '35%'],

                            label: {
                                normal: {
                                    position: 'inner'
                                }
                            },
                            labelLine: {
                                normal: {
                                    show: false
                                }
                            },
                            data:[
                                {value:10, name:'应收账款'},
                                {value:10, name:'收费收益权'},
                                {value:10, name:'信托受益权'},
                                {value:10, name:'商业票据'},
                                {value:10, name:'住房公积金'},
                                {value:10, name:'其他'},
                            ]
                        },
                        {
                            name:'访问来源',
                            type:'pie',
                            radius: ['45%', '60%'],

                            data:[
                                {value:10, name:'金融投资'},
                                {value:10, name:'旅游酒店'},
                                {value:10, name:'电子通信'},
                                {value:10, name:'化学化工'},
                                {value:10, name:'交通运输'},
                                {value:10, name:'电气设备'},
                                {value:10, name:'建筑建材'},
                                {value:10, name:'其他'},
                                {value:10, name:'家居日用'},
                                {value:10, name:'生物医药'},
                            ]
                        }
                    ]
                };
                myChart.setOption(option);