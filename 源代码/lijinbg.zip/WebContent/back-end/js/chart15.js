/**
 * 
 */
var myChart = echarts.init(document.getElementById('chart15'));
                var option = {
                         title : {
                                text: '每季度申请融资企业数量',
                                textStyle:{'fontSize':20},
                                x:'center'

                            },
                            tooltip : {
                                trigger: 'axis'
                            },

                            calculable : true,
                            xAxis : [
                                {
                                    type : 'category',
                                    boundaryGap : false,
                                    data : ["14年第4季度","15年第1季度","15年第2季度","15年第3季度","15年第4季度","16年第1季度","16年第2季度","16年第3季度"]
                                }
                            ],
                            yAxis : [
                                {
                                    type : 'value',
                                    axisLabel : {
                                        formatter: '{value} 个'
                                    }
                                }
                            ],
                            series : [
                                {

                                    type:'line',
                                    data:[ 2, 3, 4, 2, 3, 5, 4, 6],

                                    markLine : {
                                        data : [
                                            {type : 'average', name: '平均值'}
                                        ]
                                    }
                                }]
                };
myChart.setOption(option);