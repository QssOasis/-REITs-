package com.API;

import java.io.IOException;

import org.apache.commons.codec.binary.Base64;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class API {

	OkHttpClient client = new OkHttpClient();

	String run(String url) throws IOException {
	String client_id = "4796196b-b36a-4067-89f5-bfde2e19812f";
	String client_scrent = "lH1gN6aO1fF0mM5jW0pU2kV0hS6hU5bM4cU4iO3hR8iW7wS4hG";
	String encode_key = client_id + ":" + client_scrent;
	String authorization = "Basic " + Base64.encodeBase64String(encode_key.getBytes());
	
	MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
	RequestBody body = RequestBody.create(mediaType, "grant_type=client_credentials&scope=/api");
	Request request = new Request.Builder()
	    .url("https://sandbox.apihub.citi.com/gcb/api/clientCredentials/oauth2/token/hk/gcb")
		.post(body)
		.addHeader("accept", "application/json")
		.addHeader("authorization", authorization)
		.addHeader("content-type", "application/x-www-form-urlencoded")
		.build();
	try (Response response = client.newCall(request).execute()){
	 return response.body().string(); 
	}
}
	public static void main(String[] args) throws IOException {
		API api = new API();
	    String response = api.run("https://sandbox.apihub.citi.com/gcb/api/clientCredentials/oauth2/token/hk/gcb");
	    System.out.println(response);
	}
}