package com.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/listZscoreServlet")
public class ListZscoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private double x;
	private double y;
	private double z;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		x=(double) request.getAttribute("A");
		y=(double) request.getAttribute("B");
		z=(double) request.getAttribute("C");
		
		request.setAttribute("zscore",zs(x,y,z) );
		request.getRequestDispatcher("zscore.jsp");
		
	}
	
	public  String zs(double a, double b,double c) {
		double z;
		z=-3.812+4.721*a+9.078*b+0.039*c;
		
		if(z>0.747048)
			return ("���񽡿�");
		else if(-0.74173<z)
				return ("��ɫ�ش�");
		else if(z<-0.74173 )
			return ("����Σ��");
		return null;
	
		
				
			
	}
}
