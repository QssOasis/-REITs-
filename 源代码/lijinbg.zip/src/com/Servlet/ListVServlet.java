package com.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/listV")
public class ListVServlet extends HttpServlet {
			private static final long serialVersionUID = 1L;
			private double RF;    
			private double Beta;     
			private double RM;
			private double KD;
			private double TD;
			private double Tc;
			private double V1;
			private double TE;
	

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			RF=(double) request.getAttribute("RF");
			Beta=(double) request.getAttribute("Beta");
			RM=(double) request.getAttribute("RM");
			KD=(double) request.getAttribute("KD");
			TD=(double) request.getAttribute("TD");
			Tc=(double) request.getAttribute("Tc");
			V1=(double) request.getAttribute("V1");
			TE=(double) request.getAttribute("TE");
			
			double AFFO[] = new double[5];
		
			request.setAttribute("v", comV(RF,Beta, RM, KD, TD, Tc, AFFO, V1, TE));
			request.getRequestDispatcher(".jsp");
	}
	
	
	public double comV(double RF,double Beta,double RM,double KD,double TD,double Tc,double AFFO[],double V1,double TE)
	{
		double KE;
		double r;
		double V=0;
	    int i=AFFO.length;
		KE=RF+Beta*(RM-RF);
		r=KD*(TD/V1)+KE*(TE/V1)*(1-Tc);
		for(int j=0;j<i;j++)
		{
			V+=AFFO[j]/Math.pow((1+r), j);
		}
		return V;
	}

}
