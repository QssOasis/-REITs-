package com.lijin.common;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

@Component
public class BaseDao {
	
	@Resource
	private SessionFactory sessionFactory;

	public Session getSession(){

		return sessionFactory.openSession();
	}
	public Session getCurrentsession(){

		return sessionFactory.getCurrentSession();
	}	
	public void flush() {
		getSession().flush();
	}

	public void clear() {
		getSession().clear();
	}
	
	// 新加
	public void add(Object o) {
		getSession().save(o);
	}

	// 更新
	public void update(Object o) {
		getSession().update(o);
	}

	// 更新
	public void merge(Object o) {
		getSession().saveOrUpdate(o);
	}

	public Object getById(Class<?> c, Serializable id) {
		return getSession().get(c, id);
	}

	// 删除
	public void delete1(Object o) {
		getSession().delete(o);
	}

	// 根据id删除
	public void deleteById(Class<?> c, Serializable id) {
		delete1(getById(c, id));
	}
	

	public List<?> selectListByCondition(String hql,Map<String,Object> condition){
		Query query = getSession().createQuery(hql);
		setParameters(query, condition);
		query.setFirstResult(0);
		List<?> results = query.list();
		return results;
	}

			public List<?> findByProperty(Class<?> c,String propertyName ,Object value) {
				String hql = "from "+c.getSimpleName()+" as entity where entity."+propertyName+ " = ?";
				Query query = getSession().createQuery(hql);
				query.setParameter(0, value);
				query.setFirstResult(0);
				List<?> results = query.list();
				return results;
			}


	public Long countByHql(String hql, Map<String, Object> condition) {
		String countSql = "SELECT COUNT(*) "+hql;
		Query query = this.getSession().createQuery(countSql);
		setParameters(query, condition);
		return (Long) query.uniqueResult();
	}


	public List<?> getAll(Class<?> c) {
		String hql = "from "+c.getSimpleName();
		Query query = getSession().createQuery(hql);
		List<?> list = query.list();
		return list;
	}

	protected void setParameters(Query query, Map<String, Object> paramlist) {
		if (paramlist != null) {
			for (String key : paramlist.keySet()) {
				query.setParameter(key, paramlist.get(key));
			}
		}
	}
	

}