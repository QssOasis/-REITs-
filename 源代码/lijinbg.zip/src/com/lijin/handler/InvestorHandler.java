package com.lijin.handler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lijin.entities.Bond;
import com.lijin.entities.Message;
import com.lijin.entities.User_basic_info;
import com.lijin.entities.User_or_com_bank;
import com.lijin.entities.User_trade_bond;
import com.lijin.entities.User_trust_deed;
import com.lijin.service.Investor1stMarketService;
import com.lijin.service.Investor2ndMarketService;
import com.lijin.service.InvestorInfoService;
import com.lijin.utils.DbContextHolder;
import com.lijin.utils.Show2Bondinfo;

@Controller

public class InvestorHandler {

	@Autowired
	private Investor2ndMarketService investor2ndMarketService;
	@Autowired
	private Investor1stMarketService investor1stMarketService;
	@Autowired
	private InvestorInfoService investorInfoService;
	
	
	@RequestMapping("YIRON index")
	public String yironindex(){
		return "index";
	}
	@RequestMapping("index")
	public String index(Map<String,Object>map){
		List bond1=investor1stMarketService.bond1listbytime();
		List bond2=investor2ndMarketService.bond2new5();
		map.put("bond1", bond1);
		map.put("bond2", bond2);
		return "Investor/index";
	}

	@RequestMapping("purchase AllInfo")
	public String purchaseAllInfo(Map <String, Object>map){
		Integer level=null;
		String bid="";
		int pageSize=1;
		int bstatement=1;
		String orderPropertyName="bid";
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<Bond> list=investor1stMarketService.findBonds(bstatement, orderPropertyName, pageSize);
		map.put("bond", list);
		map.put("time", simpleDateFormat.format(new Date()));
		return "Investor/purchase AllInfo";
	}

	@RequestMapping("clientAlert System")
	public String clientAlertSystem(HttpSession session,Map<String ,Object>map){
		User_basic_info receiver=(User_basic_info) session.getAttribute("user");
		List list=investorInfoService.findMessage(receiver);
		List list2=new ArrayList<>();
		for(int i=0;i<list.size();i++){
			Message message=(Message) list.get(i);
			int type=message.getType();
			if (type==1){
				list2.add(message);
			}
		}
		map.put("system",list2 );
		return "Investor/clientAlert System";
	}
	@RequestMapping("clientAlert Purchase")
	public String clientAlertPurchase(HttpSession session ,Map<String, Object>map){
		User_basic_info receiver=(User_basic_info) session.getAttribute("user");
		List list=investorInfoService.findMessage(receiver);
		List list2=new ArrayList<>();
		for(int i=0;i<list.size();i++){
			Message message=(Message) list.get(i);
			int type=message.getType();
			if (type==2){
				list2.add(message);
			}
		}
		map.put("system",list2 );
		System.out.println(list2);

		
		return "Investor/clientAlert Purchase";
	}
	@RequestMapping("purchase Inquiry")
	public String purchaseInquiry(Map<String, Object>map,HttpSession session){
		int index=1;
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		map.put("time", simpleDateFormat.format(new Date()));
		map.put("bond",investor1stMarketService.showUserbought1Bond(user_basic_info, null, index));
		return "Investor/purchase Inquiry";
	}
	
	@RequestMapping("bondDetail2")
	public String bondDetail2(){
		return "Investor/bondDetail2";
	}
	@RequestMapping("bondDetail3")
	public String bondDetail3(){
		return "Investor/bondDetail3";
	}
	@RequestMapping("trade AllInfo")
	public String tradeAllInfo(Map<String, Object>map,HttpSession session){
		int pageSize=1;
		int index=1;
		String bid="";
		Integer level=null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		map.put("time", simpleDateFormat.format(new Date()));
		User_basic_info user_basic_info =(User_basic_info) session.getAttribute("user");
		List list=investor1stMarketService.marketBondInfo(bid, level, index);
		Show2Bondinfo show2Bondinfo=(Show2Bondinfo)(list.get(0));
		map.put("bond",list );
		return "Investor/trade AllInfo";
	}
	@RequestMapping("account Bankcard")
	public String accountBankcard(HttpSession session,Map<String,Object>map){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		DbContextHolder.setDbType("1");
		List<User_or_com_bank> list = investorInfoService.findBank(user_basic_info);
		map.put("card", list);
		return "Investor/account Bankcard";
	}
	@RequestMapping("account RiskTest")
	public String accountRiskTest(){
		return "Investor/account RiskTest";
	}
	@RequestMapping("clientAlert Deal")
	public String clientAlertDeal(HttpSession session,Map<String,Object>map){
		User_basic_info receiver=(User_basic_info) session.getAttribute("user");
		List list=investorInfoService.findMessage(receiver);
		List list2=new ArrayList<>();
		for(int i=0;i<list.size();i++){
			Message message=(Message) list.get(i);
			int type=message.getType();
			if (type==3){
				list2.add(message);
			}
		}
		map.put("system",list2 );

		return "Investor/clientAlert Deal";
	}

	
	@RequestMapping("clientSetting BasicInfo")
	public String clientSettingBasicInfo(){
		return "Investor/clientSetting BasicInfo";
	}

	
	@RequestMapping("clientSetting PswModify")
	public String clientSettingPswModify(){
		return "Investor/clientSetting PswModify";
	}
	
	@RequestMapping("FAQ")
	public String FAQ(){
		return "Investor/FAQ";
	}
	@RequestMapping("trade MyDeal")
	public String tradeMyDeal(Map<String , Object>map,HttpSession session){
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		User_basic_info user_basic_info =(User_basic_info) session.getAttribute("user");
		List list=investor1stMarketService.dealBond(user_basic_info);
		map.put("bond", list);
		map.put("time",simpleDateFormat.format(new Date()));		
		return "Investor/trade MyDeal";
	}
	
	@RequestMapping("trade MyFollow")
	public String tradeMyFollow(Map<String , Object>map,HttpSession session){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List list=investor1stMarketService.followBond(user_basic_info);
		//List list=investor2ndMarketService
		map.put("bond", list);
		map.put("time",simpleDateFormat.format(new Date()));
		return "Investor/trade MyFollow";
	}
	
	@RequestMapping("account Captical")
	public String accountCaptical(Map<String, Object>map,HttpSession session){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		List list=investor2ndMarketService.findUserOwnBonds(id);
		map.put("balance", balance);
		map.put("bond", list);
		return "Investor/account Captical";
	}

	@ResponseBody
	@RequestMapping("Json")
	public List<Bond> json(String bid){
		return investorInfoService.seekByUser2(null, bid, 1);
	}

	
	@ResponseBody
	@RequestMapping("Json2")
	public List json2(String bid){
		Bond bond=investorInfoService.findById(bid);
		List list=new ArrayList<>();
		List list2=investor2ndMarketService.seekBondbuy_5_trust_deeds(bond);
		List list3=investor2ndMarketService.seekBondsell_5_trust_deeds(bond);
		for(int i=0;i<list3.size();i++){//��5
		User_trust_deed user_trust_deed= (User_trust_deed) list3.get(i);
		Double price=user_trust_deed.getUtdprice();
		Integer turnover=user_trust_deed.getUtdturnover();
		list.add(price);
		list.add(turnover);
		}
		for(int i=0;i<list2.size();i++){//��5
		User_trust_deed user_trust_deed= (User_trust_deed) list2.get(i);
		Double price=user_trust_deed.getUtdprice();
		Integer turnover=user_trust_deed.getUtdturnover();
		list.add(price);
		list.add(turnover);
		}
		return list;
	}
	@RequestMapping("account Captical2")
	public String accountCaptical2(Map<String, Object>map,HttpSession session){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		List list=investor2ndMarketService.findUserOwnBonds(id);
		map.put("balance", balance);
		map.put("bond", list);
		return "Investor/account Captical2";
	}
	@RequestMapping("account Captical3")
	public String accountCaptical3(HttpSession session,Map<String,Object>map){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		map.put("balance", balance);
		Integer type=null;
		int index=1;
		List list=investor2ndMarketService.withDrawOrders(user_basic_info, type, index);
		map.put("bond", list);
		Object[] objects=(Object[]) list.get(0);
		return "Investor/account Captical3";
	}
	@RequestMapping("account Captical30")
	public String accountCaptical30(HttpSession session,Map<String,Object>map){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		map.put("balance", balance);
		Integer type=2;
		int index=1;
		List list=investor2ndMarketService.withDrawOrders(user_basic_info, type, index);
		map.put("bond", list);

		return "Investor/account Captical3";
	}
	@RequestMapping("account Captical31")
	public String accountCaptical31(HttpSession session,Map<String,Object>map){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		map.put("balance", balance);
		Integer type=1;
		int index=1;
		List list=investor2ndMarketService.withDrawOrders(user_basic_info, type, index);
		map.put("bond", list);
		Object[] objects=(Object[]) list.get(0);
		return "Investor/account Captical3";
	}
	@RequestMapping("account Captical4")
	public String accountCaptical4(HttpSession session,Map<String,Object>map){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		List list=investor2ndMarketService.findUserOwnBonds(id);
		map.put("balance", balance);
		map.put("bond", list);
		return "Investor/account Captical4";
	}
	@RequestMapping("account Captical5")
	public String accountCaptical5(HttpSession session,Map<String, Object>map){
		User_basic_info user=(User_basic_info) session.getAttribute("user");
		String id=user.getUid();
		Double balance=investorInfoService.findBalance(id);
		map.put("balance", balance);
		int index=1;
		List list=investor2ndMarketService.showTodayDealBond(user, index);
		List list2=new ArrayList<>();
		Object[] objects=null;
		for(int i=0;i<list.size();i++){
			objects=new Object[6];
			User_trade_bond user_trade_bond=(User_trade_bond) list.get(i);
			
			if(user.getUid()==user_trade_bond.getBuyerid()){
				objects[0]="����";
			}
			else{
				objects[0]="����";
			}
			
			objects[2]=user_trade_bond.getUtbdate();
			objects[3]=user_trade_bond.getUtbprice();
			objects[4]=user_trade_bond.getUtbturnover();
			objects[5]=user_trade_bond.getUtbprice()*user_trade_bond.getUtbturnover();
			list2.add(objects);
		}
		map.put("bond",list2);
		return "Investor/account Captical5";
	}
	@RequestMapping("account Captical51")
	public String accountCaptical51(HttpSession session,Map<String, Object>map){
		User_basic_info user=(User_basic_info) session.getAttribute("user");
		String id=user.getUid();
		Double balance=investorInfoService.findBalance(id);
		map.put("balance", balance);
		int index=1;
		List list=investor2ndMarketService.showHistoryDealBond(user, index);

		List list2=new ArrayList<>();
		Object[] objects=null;
		for(int i=0;i<list.size();i++){
			objects=new Object[6];
			User_trade_bond user_trade_bond=(User_trade_bond) list.get(i);
			
			if(user.getUid()==user_trade_bond.getBuyerid()){
				objects[0]="����";
			}
			else{
				objects[0]="����";
			}
			
			objects[2]=user_trade_bond.getUtbdate();
			objects[3]=user_trade_bond.getUtbprice();
			objects[4]=user_trade_bond.getUtbturnover();
			objects[5]=user_trade_bond.getUtbprice()*user_trade_bond.getUtbturnover();
			list2.add(objects);
		}
		map.put("bond",list2);
		return "Investor/account Captical51";
	}
	@RequestMapping("account Captical52")
	public String accountCaptical52(HttpSession session,Map<String, Object>map){
		User_basic_info user=(User_basic_info) session.getAttribute("user");
		String id=user.getUid();
		Double balance=investorInfoService.findBalance(id);
		map.put("balance", balance);
		int index=1;
		List list=investor2ndMarketService.clearAccount(user, index);
		List list2=new ArrayList<>();
		Object[] objects=null;
		for(int i=0;i<list.size();i++){
			objects=new Object[6];
			User_trade_bond user_trade_bond=(User_trade_bond) list.get(i);
			
			if(user.getUid()==user_trade_bond.getBid()){
				objects[0]="����";
			}
			else{
				objects[0]="����";
			}
			objects[1]=user_trade_bond.getBid();
			objects[2]=user_trade_bond.getUtbdate();
			objects[3]=user_trade_bond.getUtbprice();
			objects[4]=user_trade_bond.getUtbturnover();
			objects[5]=user_trade_bond.getUtbprice()*user_trade_bond.getUtbturnover();
			list2.add(objects);
		}
		map.put("bond",list2);
		return "Investor/account Captical52";
	}
	@RequestMapping("clientSetting PswProtect")
	public String clientSettingPswProtect(){
		return "Investor/clientSetting PswProtect";
	}
	@ModelAttribute
	public void get(Map<String, Object>map,HttpSession session){
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		if (user_basic_info!=null){
		String utel=user_basic_info.getUtel();
		User_basic_info user_basic_info2=(User_basic_info) investorInfoService.findByUtel(utel).get(0);
		map.put("user2",user_basic_info2 );}
		
	}
	@RequestMapping(value="update",method=RequestMethod.PUT)
	public String save(User_basic_info transientInstance){
		investorInfoService.save(transientInstance);
		return "redirect:/Investor/clientSetting BasicInfo";
	}
	@RequestMapping("bondDetail/{bid}")
	public String bondDetail(@PathVariable("bid")String bid,Map<String, Object>map,HttpSession session){
		Bond bond=investorInfoService.findById(bid);
		Date today=new Date();
		Date yestoday=new Date();
		
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(yestoday);
		calendar.add(calendar.DATE,-1);//��������������һ��.����������,������ǰ�ƶ�
		yestoday=calendar.getTime(); //���ʱ���������������һ��Ľ�� 
		
		Calendar calendar2 = new GregorianCalendar();
		calendar2.setTime(yestoday);
		calendar2.add(calendar2.DATE,0);//��������������һ��.����������,������ǰ�ƶ�
		today=calendar2.getTime(); //���ʱ���������������һ��Ľ�� 
		
		User_basic_info user_basic_info=(User_basic_info) session.getAttribute("user");
		String id=user_basic_info.getUid();
		Double balance=investorInfoService.findBalance(id);
		List list=investor2ndMarketService.findUserOwnBonds(id);
		
		map.put("bond2", list);
		
		map.put("balance", balance);
		map.put("bond", list);
		map.put("balance", balance);
		map.put("bond", bond);
		
		return "Investor/bondDetail";
	}
	@RequestMapping("bondDetail-1st/{bid}")
	public String bondDetail1st(){
		return "Investor/bondDetail-1st";
	}
	@ResponseBody
	@RequestMapping("Json3")
	public List json3(String bid){
		List list=new ArrayList<>();
		
		
		
		return list;
	}
	@RequestMapping(value="delete/{id}",method=RequestMethod.DELETE)
	public String delete(@PathVariable("id") String id){
		investor2ndMarketService.deleteOrder(id);
		return "redirect:/account Captical3";
	}
	
	@RequestMapping(value="deleteCard/{id}",method=RequestMethod.DELETE)
	public String deleteCard(@PathVariable("id") String id){
		investorInfoService.deleteCard(id);
		return "redirect:/account Captical3";
	}
	
	@RequestMapping("trade News")
	public String tradeNews(){
		return "Investor/trade News";
	}
	@RequestMapping("trade Notice")
	public String tradeNotice(){
		return "Investor/trade Notice";
	}
}

