package com.lijin.handler;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lijin.entities.Company_basic_info;
import com.lijin.entities.Message;
import com.lijin.entities.User_basic_info;
import com.lijin.service.InvestorInfoService;
import com.lijin.service.LoginService;

@SessionAttributes(value={"user","notRead","tixing","balance","company"})
@Controller
public class LoginHandler {
	@Autowired
	private LoginService loginService;
	@Autowired
	private InvestorInfoService investorInfoService;
	
	@RequestMapping("/YIRON login")
	public String forword1(){
		return "YIRON login";
	}
	@RequestMapping("/YIRON sign up")
	public String forword2(){
		return "YIRON sign up";
	}
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(String tel,String password,Map<String,Object>map){
		List list=loginService.login(tel);
		if (list==null){
			return "YIRON login2";
		}
		if (list.get(0).getClass()==(User_basic_info.class)&&((User_basic_info)list.get(0)).getUpassword().equals(password)){
			List bond1=loginService.bond1listbytime();
			List bond2=loginService.bond2new5();
			List message=investorInfoService.findMessage(list.get(0));
			int notRead=0;
			int alert=0;
			for(int i=0;i<message.size();i++){
				Message message2=(Message)message.get(i);
				alert++;
				if(message2.getIsRead()==1){
					notRead++;
				}
			}
			User_basic_info user_basic_info=(User_basic_info)list.get(0);
			String id=user_basic_info.getUid();
			map.put("user", list.get(0));
			map.put("bond1", bond1);
			map.put("tixing",alert);
			map.put("notRead", notRead);
			map.put("bond2", bond2);
			return "Investor/index";
		}else if(list.get(0).getClass()==(Company_basic_info.class)&&((Company_basic_info)list.get(0)).getCpassword().equals(password)){
			map.put("company", list.get(0));
			return "Company/home";}
		
		return "YIRON login2";
		
	}
}

