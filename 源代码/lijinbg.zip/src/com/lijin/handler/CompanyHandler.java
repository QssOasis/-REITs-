package com.lijin.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lijin.entities.Company_basic_info;
import com.lijin.service.CompanyService;

@SessionAttributes("financingApplication")
@Controller
public class CompanyHandler {
	@Autowired
	private CompanyService companyService;


	@RequestMapping("financing Application2")//�����ͬ�Ⲣ�������������ת����������
	public String financingApplication2(){
		return "Company/financing Application";
	}
	
	@RequestMapping("financing Application")//�����ط������������ֻ����ת��������֪
	public String financingApplication(Map<String,Object>map){
		String alert="0";
		map.put("alert",alert );
		return "Company/financing Knowing";
	}
	
	@RequestMapping("updateApplication")
	public void updateApplication(String financingMoney,String financingDuration,String assetType,String des,Map<String,Object>map){
		Map<String,Object> m=new HashMap<>();
		m.put("financingMoney", financingMoney);
		m.put("financingDuration", financingDuration);
		m.put("assetType", assetType);
		m.put("des", des);
		map.put("financingApplication", m);
	}
	
	@RequestMapping("financing History")
	public String financingHistory(Map<String ,Object>map,HttpSession session){
		Company_basic_info company_basic_info=(Company_basic_info) session.getAttribute("company");
		List list=companyService.findHistoryfinancinginfo(company_basic_info);
		map.put("history", list);
		return "Company/financing History";
	}

	
	@RequestMapping("financing Knowing")
	public String financingKnowing(){
		return "Company/financing Knowing";
	}
	
	@RequestMapping("home")
	public String home(){
		return "Company/home";
	}
	
	@RequestMapping("information Bankcard")
	public String informationBankcard(){
		return "Company/information Bankcard";
	}
	@RequestMapping("information Basic")
	public String informationBasic(){
		return "Company/information Basic";
	}
	@RequestMapping("information Message")
	public String informationMessage(){
		return "Company/information Message";
	}
	@RequestMapping("information News")
	public String informationNews(){
		return "Company/information News";
	}
	@RequestMapping("information Password")
	public String informationPassword(){
		return "Company/information Password";
	}
	@RequestMapping("problems")
	public String problems(){
		return "Company/problems";
	}

	@RequestMapping("situation")
	public String situation(Map<String ,Object>map,HttpSession session){
		Company_basic_info company_basic_info=(Company_basic_info) session.getAttribute("company");
		List list=companyService.find(company_basic_info);
		List<Object[]> list2=companyService.findHistoryfinancinginfo(company_basic_info);
		Double cost=null;
		for(Object[] objects:list2 ){
			int statement=(int) objects[7];
			if(statement>=3){
				Integer money=(Integer) objects[4];
				Double rate=(Double) objects[6]+0.005;
				cost=money*rate;
				
			}
		}
		if (list.size()==0){
			map.put("financingInfo", "�����κ�������Ϣ��");
			
		}
		else{
		map.put("financingInfo",list.get(0));
		map.put("cost",cost);
		}
		
		return "Company/situation";
	}
}