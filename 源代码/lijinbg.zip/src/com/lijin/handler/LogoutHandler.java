package com.lijin.handler;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LogoutHandler {
	
	@RequestMapping("Logout")
	public String logout(){
		return "YIRON login";
	}
}