package com.lijin.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.websocket.Decoder.Text;


@Entity
@Table(name = "message", catalog = "test")
public class Message {

	private String mid;
	private Integer type;
	private String senderid;
	private String receiverid;
	private Date date;

	private String head;
	private Text context;
	private Integer isRead;

	public Message() {
	}

	public Message(String mid) {
		this.mid = mid;
	}

	public Message(String mid, User_basic_info userBasicInfoBySenderid, User_basic_info userBasicInfoByReceiverid,
			Integer type, Date date, String head, Text context, Integer isRead) {
		this.mid = mid;
		this.senderid = senderid;
		this.receiverid = receiverid;
		this.type = type;
		this.date = date;
		this.head = head;
		this.context = context;
		this.isRead = isRead;
	}

	@Id

	@Column(name = "mid", unique = true, nullable = false, length = 11)
	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	@Column(name = "Type")
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	@Column(name = "Senderid")
	public String getSenderid() {
		return senderid;
	}

	public void setSenderid(String senderid) {
		this.senderid = senderid;
	}

	@Column(name = "Receiverid")
	public String getReceiverid() {
		return receiverid;
	}

	public void setReceiverid(String receiverid) {
		this.receiverid = receiverid;
	}

	@Column(name = "Date")
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Column(name = "Head")
	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	@Column(name = "Context")
	public Text getContext() {
		return context;
	}

	public void setContext(Text context) {
		this.context = context;
	}

	@Column(name = "IsRead")
	public Integer getIsRead() {
		return isRead;
	}

	public void setIsRead(Integer isRead) {
		this.isRead = isRead;
	}

}
