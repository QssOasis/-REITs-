package com.lijin.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "company_financing_info", catalog = "test")
public class Company_financing_info {

	private String cfiid;
	private String cid;

	private Date cfiApplydate;
	private Date cfiGetMoneyDate;
	private String financingProjectName;

	private Integer financingDeadline;
	private Integer financingAmount;
	private String introductionOfAssets;

	private Double exceptCashFlow;
	private Double exceptCashFlow3;
	private Double exceptCashFlow6;
	private Double exceptCashFlow9;
	private Double exceptCashFlow12;
	private Double exceptCashFlow24;
	private String materialPath;

	private Date expectPaymentTime;
	private Date actualPaymentTime;

	private Integer statement;
	private Double liquidityRatio;
	private Double quickRatio;
	private Double cashRatio;
	private Double WorkingCapitalpercent;
	private Double debttoassetsRatio;
	private Double PropertyRatio;
	private Double Cashflowratio;
	private Double Debtsecurityrate;

	private Double Operatingincomecashratio;
	private Double Netinterestrateonsales;
	private Double ROA1;
	private Double ROA2;
	

	public Company_financing_info() {
	}

	public Company_financing_info(String cfiid) {
		this.cfiid = cfiid;
	}

	public Company_financing_info(String cfiid, String cid, Date cfiApplydate,
			Date cfiGetMoneyDate, Double cfipercent, String financingProjectName, Integer financingDeadline,
			Integer financingAmount, String introductionOfAssets, Double exceptCashFlow,Double exceptCashFlow3,
			Double exceptCashFlow6,Double exceptCashFlow9,Double exceptCashFlow12,Double exceptCashFlow24,
			String materialPath, Date expectPaymentTime, Date actualPaymentTime,
			Integer statement, Double liquidityRatio, Double quickRatio, Double cashratio,
			Double WorkingCapitalpercent, Double debttoassetsRatio, Double PropertyRatio,
			Double Cashflowratio, Double Debtsecurityrate, Double Operatingincomecashratio, Double Netinterestrateonsales,
			Double ROA1,Double ROA2
			) {
		this.cfiid = cfiid;
		this.cid =cid;
		this.cfiApplydate = cfiApplydate;
		this.cfiGetMoneyDate = cfiGetMoneyDate;
		
		this.financingProjectName = financingProjectName;
		this.financingDeadline = financingDeadline;
		this.financingAmount = financingAmount;
		
		this.introductionOfAssets = introductionOfAssets;
		this.exceptCashFlow = exceptCashFlow;
		this.exceptCashFlow3 = exceptCashFlow3;
		this.exceptCashFlow6 = exceptCashFlow6;
		this.exceptCashFlow9 = exceptCashFlow9;
		this.exceptCashFlow12 = exceptCashFlow12;
		this.exceptCashFlow24 = exceptCashFlow24;
		this.materialPath = materialPath;
		this.expectPaymentTime = expectPaymentTime;
		this.actualPaymentTime = actualPaymentTime;
		this.statement = statement;
		this.liquidityRatio = liquidityRatio;
		this.quickRatio = quickRatio;
		
		this.WorkingCapitalpercent = WorkingCapitalpercent;
		this.debttoassetsRatio = debttoassetsRatio;
		this.PropertyRatio = PropertyRatio;
		this.Cashflowratio = Cashflowratio;
		this.Debtsecurityrate = Debtsecurityrate;
		this.Operatingincomecashratio = Operatingincomecashratio;
		this.Netinterestrateonsales = Netinterestrateonsales;
		this.ROA1 = ROA1;
		this.ROA2 = ROA2;
	}

	@Id

	@Column(name = "cfiid", unique = true, nullable = false, length = 11)
	public String getCfiid() {
		return cfiid;
	}

	public void setCfiid(String cfiid) {
		this.cfiid = cfiid;
	}

	public String getCid() {
		return cid;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cid")
	public void setCid(String cid) {
		this.cid = cid;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cfiApplydate", length = 19)
	public Date getCfiApplydate() {
		return cfiApplydate;
	}

	public void setCfiApplydate(Date cfiApplydate) {
		this.cfiApplydate = cfiApplydate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cfiGetMoneyDate", length = 19)
	public Date getCfiGetMoneyDate() {
		return cfiGetMoneyDate;
	}

	public void setCfiGetMoneyDate(Date cfiGetMoneyDate) {
		this.cfiGetMoneyDate = cfiGetMoneyDate;
	}

	@Column(name = "FinancingProjectName")
	public String getFinancingProjectName() {
		return financingProjectName;
	}

	public void setFinancingProjectName(String financingProjectName) {
		this.financingProjectName = financingProjectName;
	}

	@Column(name = "FinancingDeadline")
	public Integer getFinancingDeadline() {
		return financingDeadline;
	}

	public void setFinancingDeadline(Integer financingDeadline) {
		this.financingDeadline = financingDeadline;
	}

	@Column(name = "FinancingAmount")
	public Integer getFinancingAmount() {
		return financingAmount;
	}

	public void setFinancingAmount(Integer financingAmount) {
		this.financingAmount = financingAmount;
	}

	@Column(name = "IntroductionOfAssets")
	public String getIntroductionOfAssets() {
		return introductionOfAssets;
	}

	public void setIntroductionOfAssets(String introductionOfAssets) {
		this.introductionOfAssets = introductionOfAssets;
	}

	@Column(name = "ExceptCashFlow")
	public Double getExceptCashFlow() {
		return exceptCashFlow;
	}

	public void setExceptCashFlow(Double exceptCashFlow) {
		this.exceptCashFlow = exceptCashFlow;
	}

	@Column(name = "ExceptCashFlow3")
	public Double getExceptCashFlow3() {
		return exceptCashFlow3;
	}

	public void setExceptCashFlow3(Double exceptCashFlow3) {
		this.exceptCashFlow3 = exceptCashFlow3;
	}

	@Column(name = "ExceptCashFlow6")
	public Double getExceptCashFlow6() {
		return exceptCashFlow6;
	}

	public void setExceptCashFlow6(Double exceptCashFlow6) {
		this.exceptCashFlow6 = exceptCashFlow6;
	}

	@Column(name = "ExceptCashFlow9")
	public Double getExceptCashFlow9() {
		return exceptCashFlow9;
	}

	public void setExceptCashFlow9(Double exceptCashFlow9) {
		this.exceptCashFlow9 = exceptCashFlow9;
	}

	@Column(name = "ExceptCashFlow12")
	public Double getExceptCashFlow12() {
		return exceptCashFlow12;
	}

	public void setExceptCashFlow12(Double exceptCashFlow12) {
		this.exceptCashFlow12 = exceptCashFlow12;
	}

	@Column(name = "ExceptCashFlow24")
	public Double getExceptCashFlow24() {
		return exceptCashFlow24;
	}

	public void setExceptCashFlow24(Double exceptCashFlow24) {
		this.exceptCashFlow24 = exceptCashFlow24;
	}

	@Column(name = "MaterialPath")
	public String getMaterialPath() {
		return materialPath;
	}

	public void setMaterialPath(String materialPath) {
		this.materialPath = materialPath;
	}

	@Column(name = "ExpectPaymentTime")
	public Date getExpectPaymentTime() {
		return expectPaymentTime;
	}

	public void setExpectPaymentTime(Date expectPaymentTime) {
		this.expectPaymentTime = expectPaymentTime;
	}

	@Column(name = "ActualPaymentTime")
	public Date getActualPaymentTime() {
		return actualPaymentTime;
	}

	public void setActualPaymentTime(Date actualPaymentTime) {
		this.actualPaymentTime = actualPaymentTime;
	}

	@Column(name = "Statement")
	public Integer getStatement() {
		return statement;
	}

	public void setStatement(Integer statement) {
		this.statement = statement;
	}

	@Column(name = "LiquidityRatio")
	public Double getLiquidityRatio() {
		return liquidityRatio;
	}

	public void setLiquidityRatio(Double liquidityRatio) {
		this.liquidityRatio = liquidityRatio;
	}

	@Column(name = "QuickRatio")
	public Double getQuickRatio() {
		return quickRatio;
	}

	public void setQuickRatio(Double quickRatio) {
		this.quickRatio = quickRatio;
	}

	@Column(name = "CashRatio")
	public Double getCashRatio() {
		return cashRatio;
	}

	public void setCashRatio(Double cashRatio) {
		this.cashRatio = cashRatio;
	}

	@Column(name = "WorkingCapitalpercent")
	public Double getWorkingCapitalpercent() {
		return WorkingCapitalpercent;
	}

	public void setWorkingCapitalpercent(Double workingCapitalpercent) {
		WorkingCapitalpercent = workingCapitalpercent;
	}

	@Column(name = "DebttoassetsRatio")
	public Double getDebttoassetsRatio() {
		return debttoassetsRatio;
	}

	public void setDebttoassetsRatio(Double debttoassetsRatio) {
		this.debttoassetsRatio = debttoassetsRatio;
	}

	@Column(name = "PropertyRatio")
	public Double getPropertyRatio() {
		return PropertyRatio;
	}

	public void setPropertyRatio(Double propertyRatio) {
		PropertyRatio = propertyRatio;
	}

	@Column(name = "Cashflowratio")
	public Double getCashflowratio() {
		return Cashflowratio;
	}

	public void setCashflowratio(Double cashflowratio) {
		Cashflowratio = cashflowratio;
	}

	@Column(name = "Debtsecurityrate")
	public Double getDebtsecurityrate() {
		return Debtsecurityrate;
	}

	public void setDebtsecurityrate(Double debtsecurityrate) {
		Debtsecurityrate = debtsecurityrate;
	}

	@Column(name = "Operatingincomecashratio")
	public Double getOperatingincomecashratio() {
		return Operatingincomecashratio;
	}

	public void setOperatingincomecashratio(Double operatingincomecashratio) {
		Operatingincomecashratio = operatingincomecashratio;
	}

	@Column(name = "Netinterestrateonsales")
	public Double getNetinterestrateonsales() {
		return Netinterestrateonsales;
	}

	public void setNetinterestrateonsales(Double netinterestrateonsales) {
		Netinterestrateonsales = netinterestrateonsales;
	}

	@Column(name = "ROA1")
	public Double getROA1() {
		return ROA1;
	}

	public void setROA1(Double rOA1) {
		ROA1 = rOA1;
	}

	@Column(name = "ROA2")
	public Double getROA2() {
		return ROA2;
	}

	public void setROA2(Double rOA2) {
		ROA2 = rOA2;
	}

	@Column(name = "ROE")
	public Double getROE() {
		return ROE;
	}

	public void setROE(Double rOE) {
		ROE = rOE;
	}

	@Column(name = "Turnoverrateofaccountsreceivable")
	public Double getTurnoverrateofaccountsreceivable() {
		return Turnoverrateofaccountsreceivable;
	}

	public void setTurnoverrateofaccountsreceivable(Double turnoverrateofaccountsreceivable) {
		Turnoverrateofaccountsreceivable = turnoverrateofaccountsreceivable;
	}

	@Column(name = "Inventoryturnoverrate")
	public Double getInventoryturnoverrate() {
		return Inventoryturnoverrate;
	}

	public void setInventoryturnoverrate(Double inventoryturnoverrate) {
		Inventoryturnoverrate = inventoryturnoverrate;
	}

	@Column(name = "Currentassetturnoverrate")
	public Double getCurrentassetturnoverrate() {
		return Currentassetturnoverrate;
	}

	public void setCurrentassetturnoverrate(Double currentassetturnoverrate) {
		Currentassetturnoverrate = currentassetturnoverrate;
	}

	@Column(name = "Totalassetsturnover")
	public Double getTotalassetsturnover() {
		return Totalassetsturnover;
	}

	public void setTotalassetsturnover(Double totalassetsturnover) {
		Totalassetsturnover = totalassetsturnover;
	}

	@Column(name = "Totalassetsgrowthrate")
	public Double getTotalassetsgrowthrate() {
		return Totalassetsgrowthrate;
	}

	public void setTotalassetsgrowthrate(Double totalassetsgrowthrate) {
		Totalassetsgrowthrate = totalassetsgrowthrate;
	}

	@Column(name = "Operatingincomegrowth")
	public Double getOperatingincomegrowth() {
		return Operatingincomegrowth;
	}

	public void setOperatingincomegrowth(Double operatingincomegrowth) {
		Operatingincomegrowth = operatingincomegrowth;
	}

	@Column(name = "Totalretainedearningsperccent")
	public Double getTotalretainedearningsperccent() {
		return Totalretainedearningsperccent;
	}

	public void setTotalretainedearningsperccent(Double totalretainedearningsperccent) {
		Totalretainedearningsperccent = totalretainedearningsperccent;
	}

	private Double ROE;
	private Double Turnoverrateofaccountsreceivable;
	private Double Inventoryturnoverrate;
	private Double Currentassetturnoverrate;
	private Double Totalassetsturnover;
	private Double Totalassetsgrowthrate;
	private Double Operatingincomegrowth;
	private Double Totalretainedearningsperccent;

}
