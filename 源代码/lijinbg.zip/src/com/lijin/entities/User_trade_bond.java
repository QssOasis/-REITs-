package com.lijin.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "user_trade_bond", catalog = "test")
public class User_trade_bond {

	private String utbid;
	private String bid;
	private String buyerid;
	private String sellerid;
	private Double utbprice;
	private Date utbdate;
	private Integer utbturnover;
	private Integer type;
	private Integer statement;
	private String failedResult;

	public User_trade_bond() {
	}

	public User_trade_bond(String utbid) {
		this.utbid = utbid;
	}

	

	@Id

	@Column(name = "utbid", unique = true, nullable = false, length = 11)
	public String getUtbid() {
		return utbid;
	}

	public void setUtbid(String utbid) {
		this.utbid = utbid;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "buyerid")
	public String getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(String buyerid) {
		this.buyerid = buyerid;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sellerid")
	public String getSellerid() {
		return sellerid;
	}

	public void setSellerid(String sellerid) {
		this.sellerid = sellerid;
	}

	@Column(name = "utbprice", precision = 6)
	public Double getUtbprice() {
		return utbprice;
	}

	public void setUtbprice(Double utbprice) {
		this.utbprice = utbprice;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "utbdate", length = 19)
	public Date getUtbdate() {
		return utbdate;
	}

	public void setUtbdate(Date utbdate) {
		this.utbdate = utbdate;
	}

	@Column(name = "utbturnover")
	public Integer getUtbturnover() {
		return utbturnover;
	}

	public void setUtbturnover(Integer utbturnover) {
		this.utbturnover = utbturnover;
	}

	@Column(name = "type")
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	@Column(name = "statement")
	public Integer getStatement() {
		return statement;
	}

	public void setStatement(Integer statement) {
		this.statement = statement;
	}

	@Column(name = "failedResult", length = 50)
	public String getFailedResult() {
		return failedResult;
	}

	public void setFailedResult(String failedResult) {
		this.failedResult = failedResult;
	}

}
