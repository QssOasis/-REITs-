package com.lijin.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "user_basic_info", catalog = "test")
public class User_basic_info {

	private String uid;
	private String utel;
	private String umailBox;
	private String upassword;
	private String urealName;
	private String unickName;
	private String uIDType;
	private String uIDCard;

	private Integer riskLevel;
	private Date registerTime;
	private Date lastLogin;
	private Integer flag;
	private String question;
	private String answer;
	private String photo;

	public User_basic_info() {
	}

	public User_basic_info(String uid) {
		this.uid = uid;
	}

	public User_basic_info(String uid, String utel, String umailBox, String upassword, String urealName, String unickName,
			String uidtype, String uidcard, Integer riskLevel, Date registerTime, Date lastLogin, Integer flag,
			String question, String answer, String photo) {
		this.uid = uid;
		this.utel = utel;
		this.umailBox = umailBox;
		this.upassword = upassword;
		this.urealName = urealName;
		this.unickName = unickName;
		this.uIDType = uidtype;
		this.uIDCard = uidcard;
		this.riskLevel = riskLevel;
		this.registerTime = registerTime;
		this.lastLogin = lastLogin;
		this.flag = flag;
		this.question = question;
		this.answer = answer;
		this.photo = photo;
	}

	@Id

	@Column(name = "uid", unique = true, nullable = false, length = 11)
	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	@Column(name = "utel", length = 14)
	public String getUtel() {
		return utel;
	}

	public void setUtel(String utel) {
		this.utel = utel;
	}

	@Column(name = "umailBox", length = 20)
	public String getUmailBox() {
		return umailBox;
	}

	public void setUmailBox(String umailBox) {
		this.umailBox = umailBox;
	}

	@Column(name = "upassword", length = 20)
	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	@Column(name = "urealName", length = 10)
	public String getUrealName() {
		return urealName;
	}

	public void setUrealName(String urealName) {
		this.urealName = urealName;
	}

	@Column(name = "unickName", length = 10)
	public String getUnickName() {
		return unickName;
	}

	public void setUnickName(String unickName) {
		this.unickName = unickName;
	}

	@Column(name = "uIDType", length = 10)
	public String getuIDType() {
		return uIDType;
	}

	public void setuIDType(String uIDType) {
		this.uIDType = uIDType;
	}

	@Column(name = "uIDCard", length = 20)
	public String getuIDCard() {
		return uIDCard;
	}

	public void setuIDCard(String uIDCard) {
		this.uIDCard = uIDCard;
	}

	@Column(name = "riskLevel")
	public Integer getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(Integer riskLevel) {
		this.riskLevel = riskLevel;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "registerTime", length = 19)
	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "lastLogin", length = 19)
	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	@Column(name = "flag")
	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	@Column(name = "question", length = 25)
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	@Column(name = "answer", length = 10)
	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Column(name = "photo", length = 50)
	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}
}
