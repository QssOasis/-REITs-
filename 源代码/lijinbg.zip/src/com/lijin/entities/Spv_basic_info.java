package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "spv_basic_info", catalog = "test")
public class Spv_basic_info {

	private String spvid;
	private String spvname;

	private Integer spvlevel;
	private Integer flag;
	private String spvtel;
	private String spvpassword;
	private String extralPassword;
	
	public Spv_basic_info() {
	}

	public Spv_basic_info(String spvid) {
		this.spvid = spvid;
	}

	public Spv_basic_info(String spvid, String spvname, Integer spvlevel, Integer flag, String spvtel,
			String spvpassword,String extralPassword) {
		this.spvid = spvid;
		this.spvname = spvname;
		this.spvlevel = spvlevel;
		this.flag = flag;
		this.spvtel = spvtel;
		this.spvpassword = spvpassword;
		this.extralPassword = extralPassword;
	}
	
	@Id

	@Column(name = "spvid", unique = true, nullable = false, length = 11)
	public String getSpvid() {
		return spvid;
	}

	public void setSpvid(String spvid) {
		this.spvid = spvid;
	}

	@Column(name = "Spvname")
	public String getSpvname() {
		return spvname;
	}

	public void setSpvname(String spvname) {
		this.spvname = spvname;
	}

	@Column(name = "Spvlevel")
	public Integer getSpvlevel() {
		return spvlevel;
	}

	public void setSpvlevel(Integer spvlevel) {
		this.spvlevel = spvlevel;
	}

	@Column(name = "Flag")
	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	@Column(name = "Spvtel")
	public String getSpvtel() {
		return spvtel;
	}

	public void setSpvtel(String spvtel) {
		this.spvtel = spvtel;
	}

	@Column(name = "Spvpassword")
	public String getSpvpassword() {
		return spvpassword;
	}

	public void setSpvpassword(String spvpassword) {
		this.spvpassword = spvpassword;
	}

	@Column(name = "ExtralPassword")
	public String getExtralPassword() {
		return extralPassword;
	}

	public void setExtralPassword(String extralPassword) {
		this.extralPassword = extralPassword;
	}

}
