package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_balance", catalog = "test")
public class User_balance {

	private String uid;
	private Double balance;
	
	public User_balance() {
	}

	public User_balance(String uid) {
		this.uid = uid;
	}

	public User_balance(String uid, Double balance) {
		this.uid = uid;
		this.balance = balance;
	}

	@Id

	@Column(name = "uid", unique = true, nullable = false, length = 11)
	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	@Column(name = "balance", precision = 11)
	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

}
