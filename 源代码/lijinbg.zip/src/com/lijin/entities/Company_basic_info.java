package com.lijin.entities;


import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.websocket.Decoder.Text;

@Entity
@Table(name = "company_basic_info", catalog = "test")
public class Company_basic_info implements java.io.Serializable {

	private String cid;
	private String ctel;
	private String cpassword;
	private String cmailBox;
	private String cregisterName;
	private String cregisterIDtype;
	private String cregisterIDCard;
	private String cregisterBankAccount;
	private String cname;
	private String coffice;
	private String cICRegistrationNum;
	private String cindustry;
	
	private Text cintroduction;
	private String corpName;
	private String corpIDtype;
	private String corpIDcard;
	private String corpTel;
	
	private Integer flag;
	

	public Company_basic_info() {
	}

	public Company_basic_info(String cid) {
		this.cid = cid;
	}

	public Company_basic_info(String cid, String ctel, String cpassword, String cmailBox, String cregisterName,
			String cregisterIdtype, String cregisterIdcard, String cregisterBankAccount, String cname, String coffice,
			String cicregistrationNum, String cindustry, Text cintroduction, String corpName, String corpIdtype,
			String corpIdcard, String corpTel, Integer flag) {
		this.cid = cid;
		this.ctel = ctel;
		this.cpassword = cpassword;
		this.cmailBox = cmailBox;
		this.cregisterName = cregisterName;
		this.cregisterIDtype = cregisterIdtype;
		this.cregisterIDCard = cregisterIdcard;
		this.cregisterBankAccount = cregisterBankAccount;
		this.cname = cname;
		this.coffice = coffice;
		this.cICRegistrationNum = cicregistrationNum;
		this.cindustry = cindustry;
		this.cintroduction = cintroduction;
		this.corpName = corpName;
		this.corpIDtype = corpIdtype;
		this.corpIDcard = corpIdcard;
		this.corpTel = corpTel;
		this.flag = flag;
	}

	@Id

	@Column(name = "cid", unique = true, nullable = false)
	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	@Column(name = "ctel", length = 14 , unique = true)
	public String getCtel() {
		return ctel;
	}

	public void setCtel(String ctel) {
		this.ctel = ctel;
	}

	@Column(name = "cpassword")
	public String getCpassword() {
		return cpassword;
	}

	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}

	@Column(name = "cmailBox")
	public String getCmailBox() {
		return cmailBox;
	}

	public void setCmailBox(String cmailBox) {
		this.cmailBox = cmailBox;
	}

	@Column(name = "cregisterName")
	public String getCregisterName() {
		return cregisterName;
	}

	public void setCregisterName(String cregisterName) {
		this.cregisterName = cregisterName;
	}

	@Column(name = "cregisterIDtype")
	public String getCregisterIDtype() {
		return cregisterIDtype;
	}

	public void setCregisterIDtype(String cregisterIDtype) {
		this.cregisterIDtype = cregisterIDtype;
	}

	@Column(name = "cregisterIDCard")
	public String getCregisterIDCard() {
		return cregisterIDCard;
	}

	public void setCregisterIDCard(String cregisterIDCard) {
		this.cregisterIDCard = cregisterIDCard;
	}

	@Column(name = "cregisterBankAccount")
	public String getCregisterBankAccount() {
		return cregisterBankAccount;
	}

	public void setCregisterBankAccount(String cregisterBankAccount) {
		this.cregisterBankAccount = cregisterBankAccount;
	}

	@Column(name = "cname")
	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	@Column(name = "coffice")
	public String getCoffice() {
		return coffice;
	}

	public void setCoffice(String coffice) {
		this.coffice = coffice;
	}

	@Column(name = "cICRegistrationNum")
	public String getcICRegistrationNum() {
		return cICRegistrationNum;
	}

	public void setcICRegistrationNum(String cICRegistrationNum) {
		this.cICRegistrationNum = cICRegistrationNum;
	}

	@Column(name = "cindustry")
	public String getCindustry() {
		return cindustry;
	}

	public void setCindustry(String cindustry) {
		this.cindustry = cindustry;
	}

	@Column(name = "cintroduction", length = 65535)
	public Text getCintroduction() {
		return cintroduction;
	}

	public void setCintroduction(Text cintroduction) {
		this.cintroduction = cintroduction;
	}

	@Column(name = "corpName", length = 10)
	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	@Column(name = "corpIDtype", length = 10)
	public String getCorpIDtype() {
		return corpIDtype;
	}

	public void setCorpIDtype(String corpIDtype) {
		this.corpIDtype = corpIDtype;
	}

	@Column(name = "corpIDcard", length = 20)
	public String getCorpIDcard() {
		return corpIDcard;
	}

	public void setCorpIDcard(String corpIDcard) {
		this.corpIDcard = corpIDcard;
	}

	@Column(name = "corpTel", length = 14)
	public String getCorpTel() {
		return corpTel;
	}

	public void setCorpTel(String corpTel) {
		this.corpTel = corpTel;
	}

	@Column(name = "flag")
	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
}
