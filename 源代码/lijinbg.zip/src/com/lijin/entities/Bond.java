package com.lijin.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "bond", catalog = "test")
public class Bond implements java.io.Serializable {

	private String bid;
	private String bname;

	private Integer level;
	private Integer deadline;
	private Integer denomination;
	private Integer financingScale;
	private Double annualInterestRate;

	private Date releaseStartTime;
	private Date releaseEndTime;

	private Integer issuePrice;
	private Integer issueTurnover;
	private Integer purchasedTurnover;

	private Date listingDate;
	private Double totalTransactionAmount;
	private Integer totalTurnover;
	private Integer bstatement;
	
		public Bond() {
	}

	public Bond(String bid) {
		this.bid = bid;
	}

	public Bond(String bid, String bname, Integer level, Integer deadline, Integer denomination,
			Integer financingScale, Double annualInterestRate, Date releaseStartTime, Date releaseEndTime,
			Integer issuePrice, Integer issueTurnover, Integer purchasedTurnover, Date listingDate,
			Double totalTransactionAmount, Integer totalTurnover, 
			Integer bstatement) {
		this.bid = bid;
		this.bname = bname;
		this.level = level;
		this.deadline = deadline;
		this.denomination = denomination;
		this.financingScale = financingScale;
		this.annualInterestRate = annualInterestRate;
		this.releaseStartTime = releaseStartTime;
		this.releaseEndTime = releaseEndTime;
		this.issuePrice = issuePrice;
		this.issueTurnover = issueTurnover;
		this.purchasedTurnover = purchasedTurnover;
		this.listingDate = listingDate;
		this.totalTransactionAmount = totalTransactionAmount;
		this.totalTurnover = totalTurnover;
		this.bstatement = bstatement;
	}
	
    @Id
	
	@Column(name = "bid", unique = true, nullable = false)
	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}
	
	@Column(name = "bname")
	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}
	
    @Column(name = "level")
	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}
	
	@Column(name = "deadline")
	public Integer getDeadline() {
		return deadline;
	}

	public void setDeadline(Integer deadline) {
		this.deadline = deadline;
	}

	@Column(name = "denomination")
	public Integer getDenomination() {
		return denomination;
	}

	public void setDenomination(Integer denomination) {
		this.denomination = denomination;
	}

	@Column(name = "financingScale")
	public Integer getFinancingScale() {
		return financingScale;
	}

	public void setFinancingScale(Integer financingScale) {
		this.financingScale = financingScale;
	}

	@Column(name = "annualInterestRate")
	public Double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(Double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "releaseStartTime", length = 19)
	public Date getReleaseStartTime() {
		return releaseStartTime;
	}

	public void setReleaseStartTime(Date releaseStartTime) {
		this.releaseStartTime = releaseStartTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "releaseEndTime", length = 19)
	public Date getReleaseEndTime() {
		return releaseEndTime;
	}

	public void setReleaseEndTime(Date releaseEndTime) {
		this.releaseEndTime = releaseEndTime;
	}

	@Column(name = "issuePrice")
	public Integer getIssuePrice() {
		return issuePrice;
	}

	public void setIssuePrice(Integer issuePrice) {
		this.issuePrice = issuePrice;
	}

	@Column(name = "issueTurnover")
	public Integer getIssueTurnover() {
		return issueTurnover;
	}

	public void setIssueTurnover(Integer issueTurnover) {
		this.issueTurnover = issueTurnover;
	}

	@Column(name = "purchasedTurnover")
	public Integer getPurchasedTurnover() {
		return purchasedTurnover;
	}

	public void setPurchasedTurnover(Integer purchasedTurnover) {
		this.purchasedTurnover = purchasedTurnover;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "listingDate")
	public Date getListingDate() {
		return listingDate;
	}

	public void setListingDate(Date listingDate) {
		this.listingDate = listingDate;
	}

	@Column(name = "totalTransactionAmount")
	public Double getTotalTransactionAmount() {
		return totalTransactionAmount;
	}

	public void setTotalTransactionAmount(Double totalTransactionAmount) {
		this.totalTransactionAmount = totalTransactionAmount;
	}

	@Column(name = "totalTurnover")
	public Integer getTotalTurnover() {
		return totalTurnover;
	}

	public void setTotalTurnover(Integer totalTurnover) {
		this.totalTurnover = totalTurnover;
	}

	@Column(name = "bstatement")
	public Integer getBstatement() {
		return bstatement;
	}

	public void setBstatement(Integer bstatement) {
		this.bstatement = bstatement;
	}



	@Override
	public String toString() {
		return "Bond [bid=" + bid + ", bname=" + bname + ", level=" + level
				+ ", deadline=" + deadline + ", denomination=" + denomination + ", financingScale=" + financingScale
				+ ", annualInterestRate=" + annualInterestRate + ", releaseStartTime=" + releaseStartTime
				+ ", releaseEndTime=" + releaseEndTime + ", issuePrice=" + issuePrice + ", issueTurnover="
				+ issueTurnover + ", purchasedTurnover=" + purchasedTurnover + ", listingDate=" + listingDate
				+ ", totalTransactionAmount=" + totalTransactionAmount + ", totalTurnover=" + totalTurnover
				+  ", bstatement=" + bstatement
				+ "]";
	}

}