package com.lijin.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "user_trust_deed", catalog = "test")
public class User_trust_deed {

	private String utdid;
	private String bid;
	private String ownerid;
	private Date startDate;
	private Integer utdturnover;
	private Double utdprice;
	private Integer type;
	private Integer purchasedturnover;

	public User_trust_deed() {
	}

	public User_trust_deed(String utdid) {
		this.utdid = utdid;
	}

	public User_trust_deed(String utdid, Bond bond, User_basic_info userBasicInfo, Date startDate, Integer utdturnover,
			Double utdprice, Integer type) {
		this.utdid = utdid;
		this.bid = bid;
		this.ownerid = ownerid;
		this.startDate = startDate;
		this.utdturnover = utdturnover;
		this.utdprice = utdprice;
		this.type = type;
	}

	@Id

	@Column(name = "utdid", unique = true, nullable = false, length = 11)
	public String getUtdid() {
		return utdid;
	}

	public void setUtdid(String utdid) {
		this.utdid = utdid;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ownerid")
	public String getOwnerid() {
		return ownerid;
	}

	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "startDate", length = 19)
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	@Column(name = "utdturnover")
	public Integer getUtdturnover() {
		return utdturnover;
	}

	public void setUtdturnover(Integer utdturnover) {
		this.utdturnover = utdturnover;
	}

	public Double getUtdprice() {
		return utdprice;
	}

	@Column(name = "utdprice", precision = 6)
	public void setUtdprice(Double utdprice) {
		this.utdprice = utdprice;
	}

	public Integer getType() {
		return type;
	}

	@Column(name = "type")
	public void setType(Integer type) {
		this.type = type;
	}

	@Column(name = "purchasedturnover")
	public Integer getPurchasedturnover() {
		return purchasedturnover;
	}

	public void setPurchasedturnover(Integer purchasedturnover) {
		this.purchasedturnover = purchasedturnover;
	}

}
