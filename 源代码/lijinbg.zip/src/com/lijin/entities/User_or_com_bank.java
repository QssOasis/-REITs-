package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_or_com_bank", catalog = "test")
public class User_or_com_bank {

	private String baid;
	private String cid;
	private String uid;
	private String bankAccount;

	public User_or_com_bank() {
	}

	public User_or_com_bank(String baid) {
		this.baid = baid;
	}
                                                                                                                                                                                                                            
	public User_or_com_bank(String baid, Company_basic_info company_basic_info, User_basic_info user_basic_info, String bankAccount) {
		this.baid = baid;
		this.cid = cid;
		this.uid = uid;
		this.bankAccount = bankAccount;
	}

	@Id

	@Column(name = "baid", unique = true, nullable = false, length = 11)
	public String getBaid() {
		return baid;
	}

	public void setBaid(String baid) {
		this.baid = baid;
	}

	public String getCid() {
		return cid;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "cid")
	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	@Column(name = "bankAccount", length = 19)
	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}

}
