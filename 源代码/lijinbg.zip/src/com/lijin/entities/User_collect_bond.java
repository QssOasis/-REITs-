package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_collect_bond", catalog = "test")
public class User_collect_bond {

	private String ucbid;
	private String bid;
	private  User_basic_info owner;

	public User_collect_bond() {
	}

	public User_collect_bond(String ucbid) {
		this.ucbid = ucbid;
	}

	public User_collect_bond(String ucbid, Bond bond, User_basic_info user_basic_info) {
		this.ucbid = ucbid;
        this.bid = bid;
		this.owner = user_basic_info;
	}

	@Id

	@Column(name = "ucbid", unique = true, nullable = false, length = 11)
	public String getUcbid() {
		return ucbid;
	}

	public void setUcbid(String ucbid) {
		this.ucbid = ucbid;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public User_basic_info getOwner() {
		return this.owner;
	}

	public void setOwner(User_basic_info userBasicInfo) {
		this.owner = userBasicInfo;
	}

}
