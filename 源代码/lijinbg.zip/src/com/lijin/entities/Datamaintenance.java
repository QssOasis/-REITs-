package com.lijin.entities;

public class Datamaintenance {

	private String dmid;
	private Double x1;
	private Double x2;
	private Double x3;
	private Double x4;
	private Double x5;
	private Double x6;
	private Double x7;

	public String getDmid() {
		return dmid;
	}

	public void setDmid(String dmid) {
		this.dmid = dmid;
	}

	public Double getX1() {
		return x1;
	}

	public void setX1(Double x1) {
		this.x1 = x1;
	}

	public Double getX2() {
		return x2;
	}

	public void setX2(Double x2) {
		this.x2 = x2;
	}

	public Double getX3() {
		return x3;
	}

	public void setX3(Double x3) {
		this.x3 = x3;
	}

	public Double getX4() {
		return x4;
	}

	public void setX4(Double x4) {
		this.x4 = x4;
	}

	public Double getX5() {
		return x5;
	}

	public void setX5(Double x5) {
		this.x5 = x5;
	}

	public Double getX6() {
		return x6;
	}

	public void setX6(Double x6) {
		this.x6 = x6;
	}

	public Double getX7() {
		return x7;
	}

	public void setX7(Double x7) {
		this.x7 = x7;
	}

}
