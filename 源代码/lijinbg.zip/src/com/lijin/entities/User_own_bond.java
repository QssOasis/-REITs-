package com.lijin.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;

@Entity
@Table(name = "user_own_bond", catalog = "test")
public class User_own_bond {

	private String uobid;
	private String ownerid;
	private String bid;

	private Double uobprice;
	private Integer uobturnover;
	private Integer statement;
	private Date startdate;
	private Date enddate;

	public User_own_bond() {
	}

	public User_own_bond(String uobid) {
		this.uobid = uobid;
	}

	

	@Id

	@Column(name = "uobid", unique = true, nullable = false, length = 11)
	public String getUobid() {
		return uobid;
	}

	public void setUobid(String uobid) {
		this.uobid = uobid;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ownerid")
	public String getOwnerid() {
		return ownerid;
	}

	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	public String getBid() {
		return bid;
	}

	@Column(name = "Bid")
	public void setBid(String bid) {
		this.bid = bid;
	}

	public Double getUobprice() {
		return uobprice;
	}

	@Column(name = "Uobprice")
	public void setUobprice(Double uobprice) {
		this.uobprice = uobprice;
	}

	public Integer getUobturnover() {
		return uobturnover;
	}

	@Column(name = "Uobturnover")
	public void setUobturnover(Integer uobturnover) {
		this.uobturnover = uobturnover;
	}

	public Integer getStatement() {
		return statement;
	}

	@Column(name = "Statement")
	public void setStatement(Integer statement) {
		this.statement = statement;
	}

	public Date getStartdate() {
		return startdate;
	}

	@Column(name = "Startdate")
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

}
