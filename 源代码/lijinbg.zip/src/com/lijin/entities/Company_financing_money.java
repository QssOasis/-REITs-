package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "company_financing_money", catalog = "test")
public class Company_financing_money {

	private String cfiid;
	private Integer financingAmount;
	private Double loanRate;
	private Double actualPaymentAmount;
	
	public Company_financing_money() {
	}

	public Company_financing_money(String cfiid) {
		this.cfiid = cfiid;
	}

	public Company_financing_money(String cfiid, Integer financingAmount, Double actualPaymentAmount,
			Double loanRate) {
		this.cfiid = cfiid;
		this.actualPaymentAmount = actualPaymentAmount;
		this.loanRate = loanRate;
		this.financingAmount = financingAmount;
	}
	
	@Id

	@Column(name = "cfiid", unique = true, nullable = false)
	public String getCfiid() {
		return cfiid;
	}

	public void setCfiid(String cfiid) {
		this.cfiid = cfiid;
	}

	@Column(name = "FinancingAmount")
	public Integer getFinancingAmount() {
		return financingAmount;
	}

	public void setFinancingAmount(Integer financingAmount) {
		this.financingAmount = financingAmount;
	}

	@Column(name = "LoanRate")
	public Double getLoanRate() {
		return loanRate;
	}

	public void setLoanRate(Double loanRate) {
		this.loanRate = loanRate;
	}

	@Column(name = "ActualPaymentAmount")
	public Double getActualPaymentAmount() {
		return actualPaymentAmount;
	}

	public void setActualPaymentAmount(Double actualPaymentAmount) {
		this.actualPaymentAmount = actualPaymentAmount;
	}

}
