package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bond_loan_loss_provision", catalog = "test")
public class Bond_loan_loss_provision implements java.io.Serializable {

	private String bid;
	private Integer loanLossProvision;

	public Bond_loan_loss_provision() {
	}

	public Bond_loan_loss_provision(String bid, Integer loanLossProvision) {
		this.bid = bid;
		this.loanLossProvision = loanLossProvision;
	}
	@Id

	@Column(name = "bid", unique = true, nullable = false)	
	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	@Column(name = "loanLossProvision", nullable = false)
	public Integer getLoanLossProvision() {
		return loanLossProvision;
	}

	public void setLoanLossProvision(Integer loanLossProvision) {
		this.loanLossProvision = loanLossProvision;
	}

}
