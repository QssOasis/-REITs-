package com.lijin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bond_company_financing", catalog = "test")
public class Bond_company_financing implements java.io.Serializable {

	private String bcfid;
	private String bid;
	private String cfiid;

	public Bond_company_financing() {
	}

	public Bond_company_financing(String bcfid) {
		this.bcfid = bcfid;
	}

	public Bond_company_financing(String bcfid, Bond bond, Company_financing_info companyFinancingInfo) {
		this.bcfid = bcfid;
		this.bid = bid;
		this.cfiid = cfiid;
	}

	@Id

	@Column(name = "bcfid", unique = true, nullable = false)
	public String getBcfid() {
		return bcfid;
	}

	public void setBcfid(String bcfid) {
		this.bcfid = bcfid;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getCfiid() {
		return cfiid;
	}

	public void setCfiid(String cfiid) {
		this.cfiid = cfiid;
	}




}