package com.lijin.utils;


public class Show2Bondinfo {
	private String bid;
	private String bname;
	private Double rise;
	private Double price;
	private Double zhangdie;
	private Integer totalturnover;
	private Integer dayturnover;
	private Double dailyTransactionAmount;
	private Double startPrice;
	private Double dayHighestPrice;
	private Double dayLowestPrice;
	private Integer level;
	private Double annualInterestRate;
	private Integer shengyuqixian;
	public Show2Bondinfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public Double getRise() {
		return rise;
	}
	public void setRise(Double rise) {
		this.rise = rise;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getZhangdie() {
		return zhangdie;
	}
	public void setZhangdie(Double zhangdie) {
		this.zhangdie = zhangdie;
	}
	public Integer getTotalturnover() {
		return totalturnover;
	}
	public void setTotalturnover(Integer totalturnover) {
		this.totalturnover = totalturnover;
	}
	public Integer getDayturnover() {
		return dayturnover;
	}
	public void setDayturnover(Integer dayturnover) {
		this.dayturnover = dayturnover;
	}
	public Double getDailyTransactionAmount() {
		return dailyTransactionAmount;
	}
	public void setDailyTransactionAmount(Double dailyTransactionAmount) {
		this.dailyTransactionAmount = dailyTransactionAmount;
	}
	public Double getStartPrice() {
		return startPrice;
	}
	public void setStartPrice(Double startPrice) {
		this.startPrice = startPrice;
	}
	public Double getDayHighestPrice() {
		return dayHighestPrice;
	}
	public void setDayHighestPrice(Double dayHighestPrice) {
		this.dayHighestPrice = dayHighestPrice;
	}
	public Double getDayLowestPrice() {
		return dayLowestPrice;
	}
	public void setDayLowestPrice(Double dayLowestPrice) {
		this.dayLowestPrice = dayLowestPrice;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public Double getAnnualInterestRate() {
		return annualInterestRate;
	}
	public void setAnnualInterestRate(Double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	public Integer getShengyuqixian() {
		return shengyuqixian;
	}
	public void setShengyuqixian(Integer shengyuqixian) {
		this.shengyuqixian = shengyuqixian;
	}
	@Override
	public String toString() {
		return "Show2Bondinfo [bname=" + bname + ", rise=" + rise + ", price=" + price + ", zhangdie=" + zhangdie
				+ ", totalturnover=" + totalturnover + ", dayturnover=" + dayturnover + ", dailyTransactionAmount="
				+ dailyTransactionAmount + ", startPrice=" + startPrice + ", dayHighestPrice=" + dayHighestPrice
				+ ", dayLowestPrice=" + dayLowestPrice + ", level=" + level + ", annualInterestRate="
				+ annualInterestRate + ", shengyuqixian=" + shengyuqixian + "]";
	}
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	
	

}

