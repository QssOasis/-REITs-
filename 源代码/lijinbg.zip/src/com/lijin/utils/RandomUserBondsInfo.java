package com.lijin.utils;

import java.util.Date;

import com.lijin.entities.User_collect_bond;
import com.lijin.entities.User_own_bond;
import com.lijin.entities.User_trade_bond;
import com.lijin.entities.User_trust_deed;

public class RandomUserBondsInfo {
	
	public static  User_trust_deed  getUser_trust_deed(){		
		 String utdid = RandomDataUtils.randomId();
		 User_trust_deed utd=new User_trust_deed();
		 utd.setUtdid(utdid);
		return utd;		
	}
	
	
	public static  User_trade_bond getUser_trade_bond(){		
		 String utbid = RandomDataUtils.randomId();
		 Date startDate = new Date();
		 double  utbprice =  RandomDataUtils.randomDouble(96.00, 104.00);
		 Integer turnover = RandomDataUtils.randomInt(20, 200);
		
		 User_trade_bond utb=new User_trade_bond();
		 utb.setUtbid(utbid);
		 utb.setUtbturnover(turnover);
		 utb.setUtbdate(startDate);
		 utb.setUtbprice(utbprice);
	
		return utb;		
	}

	public static User_own_bond getUser_own_bond(){		
		User_own_bond user_own_bond = new User_own_bond();
		user_own_bond.setUobid(RandomDataUtils.randomId());		
		return user_own_bond;
	}
	
	public static User_collect_bond getUser_collect_bond(){		
		User_collect_bond User_collect_bond = new User_collect_bond();
		User_collect_bond.setUcbid(RandomDataUtils.randomId());		
		return User_collect_bond;
	}
	

}
