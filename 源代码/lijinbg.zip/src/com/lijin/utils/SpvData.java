package com.lijin.utils;

import com.lijin.entities.Spv_basic_info;

public class SpvData {

	public static Spv_basic_info getspv_basic_info(){
		String spvid = RandomDataUtils.randomId();
		String spvname = RandomDataUtils.randomUserName();
		String spvtel = RandomDataUtils.randomTel();
		String spvpassword = RandomDataUtils.randompassword();
		Integer spvlevel = 2;
		Integer flag = 3;
		
		Spv_basic_info spv_basic_info = new Spv_basic_info();
		
		spv_basic_info.setFlag(flag);
		spv_basic_info.setSpvid(spvid);
		spv_basic_info.setSpvlevel(spvlevel);
		spv_basic_info.setSpvname(spvname);
		spv_basic_info.setSpvpassword(spvpassword);
		spv_basic_info.setSpvtel(spvtel);
		
		System.out.println(spv_basic_info);
		return spv_basic_info;
	}
}