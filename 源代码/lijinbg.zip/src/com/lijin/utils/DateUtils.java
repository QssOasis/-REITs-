package com.lijin.utils;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	public static Date changeDate(Date date,String dateformatter){
		SimpleDateFormat sdf = new SimpleDateFormat(dateformatter);
		 String time  = sdf.format(date);
		 DateFormat df  = new SimpleDateFormat(dateformatter);
		 Date currentTime_2 = null;
		try {
			currentTime_2 = df.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return currentTime_2; 		
	}
	
	
	public static Date getNowDate(){
		 Date date  = new Date();
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 String time  = sdf.format(date);
		 DateFormat df  = new SimpleDateFormat("yyyy-MM-dd");
		 Date currentTime_2 = null;
		try {
			currentTime_2 = df.parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   return currentTime_2;
	}
}
