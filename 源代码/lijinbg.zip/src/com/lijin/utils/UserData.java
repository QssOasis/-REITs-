package com.lijin.utils;


import java.util.Date;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.lijin.entities.User_basic_info;




public class UserData {
	public static User_basic_info getUser(){
	 String uid = RandomDataUtils.randomId(); 
	 String utel = RandomDataUtils.randomTel();
	 String umailBox = RandomDataUtils.randomMailBox();
	 String upassword = RandomDataUtils.randompassword();
	 String urealName = RandomDataUtils.randomUserName();
	 String unickName = RandomDataUtils.randomUserName();
	 String uIDType = "����֤";
	 String uIDCard = RandomDataUtils.randomuIDCard();
	 Integer riskLevel = 0;
	 Date registerTime = new Date();
	 Integer flag = 1;
     
	 User_basic_info user_basic_info = new User_basic_info();
	 user_basic_info.setuIDCard(uIDCard);
	 user_basic_info.setuIDType(uIDType);
	 user_basic_info.setUid(uid);
	 user_basic_info.setRegisterTime(registerTime);
	 user_basic_info.setRiskLevel(riskLevel);
	 user_basic_info.setUtel(utel);
	 user_basic_info.setUmailBox(umailBox);
	 user_basic_info.setUpassword(upassword);
	 user_basic_info.setUrealName(urealName);
	 user_basic_info.setUnickName(unickName);
	 user_basic_info.setFlag(flag);
	 
	 return user_basic_info;
}
}
