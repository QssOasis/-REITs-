package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Company_basic_info;
import com.lijin.entities.Company_financing_info;

public interface Company_financing_infoDao {

	void save(Company_financing_info transientInstance);
	
	void delete(Company_financing_info persistentInstance);
	
	Company_financing_info findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Company_financing_info instance);
	
	List findByCompany_basic_info(Company_basic_info company_basic_info);
	
	List findCurrentCompany_financing_info(Company_basic_info company_basic_info);
	
	List findHistoryCompany_financing_info(Company_basic_info company_basic_info);

	List findALLActive();
	
	List uncheckedCorpsAsset();
	
	void updateCorpState3(String cfiid);
	
	void updateCorpState2(String cfiid);

	List checkedCorpsAsset();
}
