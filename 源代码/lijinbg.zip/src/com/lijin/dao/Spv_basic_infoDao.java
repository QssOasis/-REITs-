package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Spv_basic_info;

public interface Spv_basic_infoDao {

	void save(Spv_basic_info transientInstance);
	
	void delete(Spv_basic_info persistentInstance); 
	
	Spv_basic_info findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Spv_basic_info instance);
	
	List findByTel(String tel);
}