package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Company_basic_info;

public interface Company_basic_infoDao {
	
	void save(Company_basic_info transientInstance);
	
	void delete(Company_basic_info persistentInstance);
	
	Company_basic_info findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Company_basic_info instance);
	
	List findByCtel(String ctel);

	Long findBySindustry(String industry);
	
	Long findAll();
}
