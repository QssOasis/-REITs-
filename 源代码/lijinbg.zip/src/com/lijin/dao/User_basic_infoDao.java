package com.lijin.dao;

import java.util.List;

import com.lijin.entities.User_basic_info;

public interface User_basic_infoDao {
	
	void save(User_basic_info transientInstance);
	
	void delete(User_basic_info persistentInstance);
	
	User_basic_info findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(User_basic_info instance);
	
	List findByUtel(Object utel);
	
	List findALL();
}

