package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Message;

public interface MessageDao {
	
	void save(Message transientInstance);
	
	void delete(Message persistentInstance);
	
	Message findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Message instance);
	
	List findByReceiver(Object receiver);
	
	List findBySender(Object sender);
	

}