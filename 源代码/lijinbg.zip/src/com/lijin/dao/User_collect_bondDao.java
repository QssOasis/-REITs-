package com.lijin.dao;

import java.util.List;

import com.lijin.entities.User_collect_bond;

public interface User_collect_bondDao {

	void save(User_collect_bond transientInstance);
	
	void delete(User_collect_bond persistentInstance);
	
	User_collect_bond findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(User_collect_bond instance);
	
	List findByOwner(Object owner);
	
}

