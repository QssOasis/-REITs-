package com.lijin.dao;

import java.util.List;

import com.lijin.entities.User_or_com_bank;

public interface User_or_com_bankDao {
	
	void save(User_or_com_bank transientInstance);
	
	void delete(User_or_com_bank persistentInstance);
	
	User_or_com_bank findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(User_or_com_bank instance);
	
	List findByUser(Object user_basic_info);
	
	List findByCompany(Object company_basic_info);
}