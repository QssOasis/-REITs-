package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Bond;

public interface BondDao {
	
	void save(Bond transientInstance);
	
	void delete(Bond persistentInstance); 
	
	Bond findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Bond instance);
	
	List findALL();
	
	List findBybname(Object bname);
	
	List findBonds(Integer bstatement , String orderPropertyName , int pageSize);
	
	List seekByUser(Integer bstatement,Integer level,String bid ,int index);
	
	List bond2listbytime(int pageSize);
	
	List bond2listbyturnover();
	
	List bond1listbytime();
	
	List bond1listbyturnover(int pageSize);
	
	List seekByUser2(Integer level,String bid ,int index );
	
	List seekByUser1(Integer level,String bid , int index);
	
}
