package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Bond;
import com.lijin.entities.User_basic_info;
import com.lijin.entities.User_trust_deed;

public interface User_trust_deedDao {
	
	void save(User_trust_deed transientInstance);
	
	void delete(User_trust_deed persistentInstance);
	
	User_trust_deed findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(User_trust_deed instance);
	
	List seekTrust_deed(Bond bond ,double utdprice , Integer type);
	
	List showUser_trust_deeds(User_basic_info owner , Integer type , int index);
	
	List showBond_trust_deeds(Bond bond,Integer type);
	
	List seekBondbuy_5_trust_deeds(Bond bond);
	
	List seekBondsell_5_trust_deeds(Bond bond);

	List findUB(Bond bond, User_basic_info user_basic_info);
    
	void deleteOrders(String id);

		
}

