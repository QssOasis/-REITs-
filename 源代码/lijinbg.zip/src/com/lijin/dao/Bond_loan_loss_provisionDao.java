package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Bond_loan_loss_provision;

public interface Bond_loan_loss_provisionDao {

	void save(Bond_loan_loss_provision transientInstance);
	
	void delete(Bond_loan_loss_provision persistentInstance); 
	
	Bond_loan_loss_provision findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Bond_loan_loss_provision instance);
	
	
}
