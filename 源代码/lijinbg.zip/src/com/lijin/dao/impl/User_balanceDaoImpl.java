package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_balanceDao;
import com.lijin.entities.User_balance;

@Repository
public class User_balanceDaoImpl extends BaseDao implements User_balanceDao{

	@Override
	public void save(User_balance transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(User_balance persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public User_balance findById(String id) {
		return (User_balance) getById(User_balance.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_balance.class, propertyName, value);
	}

	@Override
	public void attachDirty(User_balance instance) {
		merge(instance);
		
	}

}