package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.Company_financing_moneyDao;
import com.lijin.entities.Company_financing_money;

@Repository("company_financing_moneyDao")
public class Company_financing_moneyDaoImpl extends BaseDao implements Company_financing_moneyDao{

	@Override
	public void save(Company_financing_money transientInstance) {
		System.out.println(transientInstance);
		add(transientInstance);
		
	}

	@Override
	public void delete(Company_financing_money persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public Company_financing_money findById(String id) {
		System.out.println((Company_financing_money) getById(Company_financing_money.class, id));
		return (Company_financing_money) getById(Company_financing_money.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Company_financing_money.class, propertyName, value);
	}

	@Override
	public void attachDirty(Company_financing_money instance) {
		merge(instance);
		
	}

	
}
