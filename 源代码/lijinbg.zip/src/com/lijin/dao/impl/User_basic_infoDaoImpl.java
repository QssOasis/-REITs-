package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_basic_infoDao;
import com.lijin.entities.User_basic_info;

@Repository
public class User_basic_infoDaoImpl extends BaseDao implements User_basic_infoDao{	

	public static final String UTEL = "utel";

	@Override
	public void save(User_basic_info transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(User_basic_info persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public User_basic_info findById(String id) {
		return (User_basic_info) getById(User_basic_info.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_basic_info.class, propertyName, value);
	}

	@Override
	public void attachDirty(User_basic_info instance) {
		merge(instance);
		
	}

	
	//�����ֻ��ţ����ظ���Ͷ����
	@Override
	public List findByUtel(Object utel) {
		return findByProperty(UTEL, utel);
	}

	@Override
	public List findALL() {
		String hql ="from User_basic_info";
		return getSession().createQuery(hql).list();
	}
}

