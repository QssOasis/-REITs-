package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.Bond_loan_loss_provisionDao;
import com.lijin.entities.Bond_loan_loss_provision;



@Repository
public class Bond_loan_loss_provisionDaoImpl extends BaseDao implements Bond_loan_loss_provisionDao{

	@Override
	public void save(Bond_loan_loss_provision transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(Bond_loan_loss_provision persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public Bond_loan_loss_provision findById(String id) {
		return (Bond_loan_loss_provision) getById(Bond_loan_loss_provision.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Bond_loan_loss_provision.class, propertyName, value);
	}

	@Override
	public void attachDirty(Bond_loan_loss_provision instance) {
		merge(instance);
		
	}


	
}