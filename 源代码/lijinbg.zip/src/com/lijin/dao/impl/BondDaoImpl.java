package com.lijin.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.BondDao;
import com.lijin.entities.Bond;

@Repository("bondDao")
public class BondDaoImpl extends BaseDao implements BondDao {
	
	public static final String PURCHASEDTURNOVER = "purchasedTurnover";
	public static final String RELEASESTARTTIME = "releaseStartTime";
	public static final String LISTINGDATE = "listingDate";
	public static final String TOTALTURNOVER = "totalTurnover";
	public static final String BNAME = "bname";
	
	@Override
	public void save(Bond transientInstance) {	
		add(transientInstance);
		
	}
	@Override
	public void delete(Bond persistentInstance) {
		System.out.println("delete in dao" + persistentInstance);
		delete1(persistentInstance);
		
	}
	@Override
	public Bond findById(String id) {
		return (Bond) getById(Bond.class, id);
	}
	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Bond.class, propertyName, value);
	}
	@Override
	public void attachDirty(Bond instance) {
		attachDirty(instance);
		
	}
	@Override
	public List findBybname(Object bname) {
		return findByProperty(BNAME, bname);
	}

	@Override
	public List findBonds(Integer bstatement, String orderPropertyName, int pageSize) {
		String  hql = null;
		if(bstatement == 1){
			hql = "from Bond b where bstatement = 1 and  b.purchasedTurnover < b.issueTurnover order by "
		+orderPropertyName+" desc";
		}else if (bstatement == 2) {
			hql = "from Bond where bstatement = 2  order by "+orderPropertyName+" desc";
		}
		Query query = getSession().createQuery(hql);
		query.setFirstResult(0);
		query.setMaxResults(pageSize);
		return query.list();		
	}
	
	@Override
	public List seekByUser(Integer bstatement, Integer level, String bid, int index) {
		 String hql ;
 		 Query query;
 		if(level != null){
			hql="from Bond b where b.level = ? and b.bid like ? and bstatement = ?";
			query = getSession().createQuery(hql);
			query.setParameter(0, level).setParameter(1, "%"+bid+"%").setParameter(2, bstatement);
		
 		}else{
 			hql="from Bond b where b.bid like ? and bstatement = ? ";
 			query = getSession().createQuery(hql);
 			query.setParameter(0, "%"+bid+"%").setParameter(1, bstatement);
 		}
 		query.setFirstResult(0+10*(index-1));
		query.setMaxResults(10);
		return query.list();
	}
	
	//�����г���������ծȯ��Ϣ
	@Override
	public List bond2listbytime(int pageSize) {
		return findBonds(2, LISTINGDATE,pageSize);  
	}

	//�����г�����ծȯ��Ϣ
	@Override
	public List bond2listbyturnover() {
		return findBonds(2, TOTALTURNOVER,10); 
	}
	
	//һ���г���������ծȯ��Ϣ
	@Override
	public List bond1listbytime() {
		return findBonds(1, RELEASESTARTTIME,10);  
	}
	
	//һ���г�����ծȯ��Ϣ
	@Override
	public List bond1listbyturnover(int pageSize) {
		 return findBonds(1 , PURCHASEDTURNOVER,pageSize);	
	}
	
	//�����г���������
	@Override
	public List seekByUser2(Integer level, String bid, int index) {
		return seekByUser(2,level,bid,index);
	}
	
	
	//һ���г���������
	@Override
	public List seekByUser1(Integer level, String bid, int index) {
		return seekByUser(1,level,bid,index); 
	}
	@Override
	public List findALL() {
		String hql = "from Bond";
		return getSession().createQuery(hql).list();		 
	}
		
	
	


}
