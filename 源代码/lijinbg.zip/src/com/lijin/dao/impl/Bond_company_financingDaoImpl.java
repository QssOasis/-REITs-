package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.Bond_company_financingDao;
import com.lijin.entities.Bond;
import com.lijin.entities.Bond_company_financing;
import com.lijin.entities.Company_financing_info;

@Repository("bond_company_financingDao")
public class Bond_company_financingDaoImpl extends BaseDao implements Bond_company_financingDao{

	public static final String COMPANY_FINANCING_INFO = "company_financing_info";
	public static final String BOND = "bond";
	
	
	@Override
	public void save(Bond_company_financing transientInstance) {
		add(transientInstance);
		
	}
	@Override
	public void delete(Bond_company_financing persistentInstance) {
		delete1(persistentInstance);
		
	}
	@Override
	public Bond_company_financing findById(String id) {
		return (Bond_company_financing) getById(Bond_company_financing.class, id);
	}
	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Bond_company_financing.class,propertyName, value);
	}
	@Override
	public void attachDirty(Bond_company_financing instance) {
		merge(instance);
		
	}
	
	
	//ͨ��ծȯ�ҵ���˾ծȯ��Ϣ
	@Override
	public List findByBond(Bond bond) {
		return findByProperty(BOND, bond);
	}
	
	//ͨ����˾��Ϣ�ҵ���˾ծȯ��Ϣ
	@Override
	public List findByCompany_financing_info(Company_financing_info company_financing_info) {
		return findByProperty(COMPANY_FINANCING_INFO, company_financing_info);
	}
	
	

	
}

