package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_or_com_bankDao;
import com.lijin.entities.User_or_com_bank;

@Repository
public class User_or_com_bankDaoImpl extends BaseDao implements User_or_com_bankDao{

	private static final String USER_BASIC_INFO = "user_basic_info";
	private static final String COMPANY_BASIC_INFO = "company_basic_info";
	@Override
	public void save(User_or_com_bank transientInstance) {
		add(transientInstance);
		
	}
	@Override
	public void delete(User_or_com_bank persistentInstance) {
		delete1(persistentInstance);
	}
	@Override
	public User_or_com_bank findById(String id) {
		return (User_or_com_bank) getById(User_or_com_bank.class, id);
	}
	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_or_com_bank.class, propertyName, value);
	}
	@Override
	public void attachDirty(User_or_com_bank instance) {
		merge(instance);
		
	}
	
	//���ظ���Ͷ���ߵ����п���Ϣ
	@Override
	public List findByUser(Object user_basic_info) {
		return findByProperty(USER_BASIC_INFO, user_basic_info);
	}
	
	
	//������ҵ�����п���Ϣ
	@Override
	public List findByCompany(Object company_basic_info) {
		return findByProperty(COMPANY_BASIC_INFO, company_basic_info);
	}
	
	
	

}

