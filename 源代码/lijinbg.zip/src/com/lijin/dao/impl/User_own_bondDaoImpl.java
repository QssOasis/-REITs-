package com.lijin.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_own_bondDao;
import com.lijin.entities.User_own_bond;

@Repository
public class User_own_bondDaoImpl extends BaseDao implements User_own_bondDao{
	
	public static final String OWNER = "owner";
	public static final String BOND = "bond";
	public static final String STATEMENT = "statement";


	@Override
	public void save(User_own_bond transientInstance) {
		add(transientInstance);
		
	}


	@Override
	public void delete(User_own_bond persistentInstance) {
		delete1(persistentInstance);
		
	}


	@Override
	public User_own_bond findById(String id) {
		return (User_own_bond) getById(User_own_bond.class, id);
	}


	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_own_bond.class, propertyName, value);
	}


	@Override
	public List findByProperty(String propertyName1, String propertyName2, Object value1, Object value2) {
		String hql = "from User_own_bond uob where uob."+propertyName1+"= ? and"+propertyName2+"= ?";
		return getSession().createQuery(hql).setParameter(0, value1).setParameter(1, value2).list();
		}


	@Override
	public void attachDirty(User_own_bond instance) {
		merge(instance);
		
	}

	
	//�����û�������ָ��ծȯ�ļ�¼
	public List getUserBond(Object owner , Object bond){
		return findByProperty(OWNER, BOND, owner, bond);
	}
	

	//�����û�һ��ֵ�ծȯ
	public List showUserSoldBond(Object owner , int index){
		String hql = "from User_own_bond where owner = ? and statement != 1 ";
		Query query = getSession().createQuery(hql).setParameter(0,owner);
		query.setFirstResult(0+10*(index-1));
		query.setMaxResults(10);
		List<User_own_bond> list = query.list();
		return list;		
	}

	public List showUserOwnBond(Object owner , int index){
		String hql = "from User_own_bond where owner = ? and statement = 1";
		return getSession().createQuery(hql).setParameter(0, owner).setFirstResult(0+10*(index-1)).setMaxResults(10).list();

	}
}