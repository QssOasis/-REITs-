package com.lijin.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_trust_deedDao;
import com.lijin.entities.Bond;
import com.lijin.entities.User_basic_info;
import com.lijin.entities.User_trust_deed;

@Repository
public class User_trust_deedDaoImpl extends BaseDao implements User_trust_deedDao{
	
	@Override
	public void save(User_trust_deed transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(User_trust_deed persistentInstance) {
		delete1(persistentInstance);
		
	}


	@Override
	public User_trust_deed findById(String id) {
		return (User_trust_deed) getById(User_trust_deed.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_trust_deed.class, propertyName, value);
	}

	@Override
	public void attachDirty(User_trust_deed instance) {
		merge(instance);
		
	}
	
	
	//个体投资者挂售或求购债券
	public  List<User_trust_deed> showUser_trust_deeds(User_basic_info owner , Integer type , int index){	
		Session session=getSession();
		Query query;
		String hql;
		if(type != null){
			hql="from User_trust_deed utd where utd.owner = ? and utd.type = ? order by startDate desc";
			query = session.createQuery(hql).setParameter(0, owner);
			query.setParameter(1, type);
		}else{
			hql="from User_trust_deed utd where utd.owner = ? order by startDate desc";
			query = session.createQuery(hql).setParameter(0, owner);
		}
		query.setFirstResult(0+10*(index-1));
		query.setMaxResults(10);	
		List<User_trust_deed> list=query.list();
		return list;		 
	}
	 
	 
	 //按“挂售”或“求购”类型返回用户债券
	 public List showBond_trust_deeds(Bond bond,Integer type){
		 Session session=getSession();
		 String hql;
		 if(type == 1){
			 hql="from User_trust_deed u where u.bond = ? and u.type = 1 order by utdprice desc";	
		 }else{
			 hql="from User_trust_deed u where u.bond = ? and u.type = 2 order by utdprice asc";
		 }
		Query query = session.createQuery(hql).setParameter(0, bond);
		query.setFirstResult(0);
		query.setMaxResults(5);	
		return query.list();
	 }


	
	@Override
	public List seekTrust_deed(Bond bond, double utdprice, Integer type) {
		Session session=getSession();
		String hql = "from User_trust_deed utd where utd.bond = ? and utd.utdprice = ? and type = ? order by utd.startDate" ;
		Query query = session.createQuery(hql).setParameter(0, bond).setParameter(1, utdprice);
		query.setParameter(2, type);
		query.setFirstResult(0);
		query.setMaxResults(1);
		return query.list();		
	}
	@Override
	public List findUB(Bond bond,User_basic_info user_basic_info){ 
		String hql = "from User_trust_deed where bond = ? and owner = ? and type = 2";
		return getSession().createQuery(hql).setParameter(0, bond).setParameter(1, user_basic_info).list();
		
	}
	
	//	鏉╂柨娲栨稊锟�54321閻ㄥ嫬顫欓幍妯哄礋娣団剝浼�
	public List seekBondbuy_5_trust_deeds(Bond bond){
		return showBond_trust_deeds(bond, 2);
	}
	
//	鏉╂柨娲栭崡锟�54321閻ㄥ嫬顫欓幍妯哄礋娣団剝浼�
	public List seekBondsell_5_trust_deeds(Bond bond){
		return showBond_trust_deeds(bond, 1);
	}
	//鎾ら攢璁㈠崟
	@Override
    public void deleteOrders(String id){
    	String hql="delete from User_trust_deed u  where u.utdid=?";


    	Query query=getSession().createQuery(hql);
    	query.setString(0,id);
    	query.executeUpdate();
           }
}
