package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.Spv_basic_infoDao;
import com.lijin.entities.Spv_basic_info;

@Repository
public class Spv_basic_infoDaoImpl extends BaseDao implements Spv_basic_infoDao{

	
	public static final String SPVTEL = "spvtel";
	@Override
	public void save(Spv_basic_info transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(Spv_basic_info persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public Spv_basic_info findById(String id) {
		return (Spv_basic_info) getById(Spv_basic_info.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Spv_basic_info.class, propertyName, value);
	}

	@Override
	public void attachDirty(Spv_basic_info instance) {
		merge(instance);
		
	}

	@Override
	public List findByTel(String tel) {
		return findByProperty(SPVTEL, tel);
		
	}
	
}