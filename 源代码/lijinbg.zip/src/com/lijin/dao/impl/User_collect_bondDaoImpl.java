package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_collect_bondDao;
import com.lijin.entities.User_collect_bond;

@Repository
public class User_collect_bondDaoImpl extends BaseDao implements User_collect_bondDao{
	
	public static final String OWNER = "owner";

	@Override
	public void save(User_collect_bond transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(User_collect_bond persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public User_collect_bond findById(String id) {
		return (User_collect_bond) getById(User_collect_bond.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_collect_bond.class, propertyName, value);
	}

	@Override
	public void attachDirty(User_collect_bond instance) {
		merge(instance);
		
	}

	
	//���ظ���Ͷ������ӵ�е�ծȯ
	@Override
	public List findByOwner(Object owner) {
		return findByProperty(OWNER, owner);
	}

	

}
