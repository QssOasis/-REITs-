package com.lijin.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.User_trade_bondDao;
import com.lijin.entities.User_trade_bond;

@Repository
public class User_trade_bondDaoImpl extends BaseDao implements User_trade_bondDao{
	public static final String BOND = "bond";

	@Override
	public void save(User_trade_bond transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(User_trade_bond persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public User_trade_bond findById(String id) {
		return (User_trade_bond) getById(User_trade_bond.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(User_trade_bond.class, propertyName, value);
	}

	@Override
	public void attachDirty(User_trade_bond instance) {
		merge(instance);
		
	}


	//�û���ּ�¼������
	public List seekqingcangbuyUser_trade_bond(Object user,Object bond,Object begin , Object end){	
		Session session = getSession();
		String hql = "from User_trade_bond where buyer = ?   and  bond = ?  and utbdate between ? and ? and type = 2";
		Query query = session.createQuery(hql).setParameter(0, user);
		query.setParameter(1, bond);
		query.setParameter(2, begin);
		query.setParameter(3, end);
		return query.list();
	}	
	
	//�û���֣�����
		public List seekqingcangsellUser_trade_bond(Object user,Object bond,Object begin , Object end){	
			Session session = getSession();
			String hql = "from User_trade_bond where seller = ?   and  bond = ?  and utbdate between ? and ? and type = 2";
			Query query = session.createQuery(hql).setParameter(0, user);
			query.setParameter(1, bond);
			query.setParameter(2, begin);
			query.setParameter(3, end);
			return query.list();
		}	
	
	//�ѳɽ�ծȯ
	public List<User_trade_bond> showDealBond(Object user , Date begin , Date end ,int index){
		Session session = getSession();
		String hql = "from User_trade_bond where (buyer = ? or seller = ?) and utbdate between ? and ? and type = 2 order by utbdate desc";
		Query query = session.createQuery(hql);
		query.setParameter(0, user);
		query.setParameter(1, user);
		query.setParameter(2, begin);
		query.setParameter(3, end);
		query.setFirstResult(0+10*(index-1));
		query.setMaxResults(10);
		return  query.list();		
	}
	
	
	//	���깺ծȯ
	public List showUserbought1Bond(Object owner , Integer type ,int index){
		Session session = getSession();
		Query query;
		if(type != null){
		String hql = "from User_trade_bond where buyer = ? and statement = 1 and type = ?";
		query = session.createQuery(hql).setParameter(0, owner);		
		query.setParameter(1, type);
		}else{
			String hql = "from User_trade_bond where buyer = ? and statement = 1 ";
			query = session.createQuery(hql).setParameter(0, owner);
		}
		query.setFirstResult(0+10*(index-1));
		query.setMaxResults(10);
		List<User_trade_bond> list = query.list();
		return list;		
	}



	
		
}
