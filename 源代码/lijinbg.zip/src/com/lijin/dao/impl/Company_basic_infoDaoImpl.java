package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.Company_basic_infoDao;
import com.lijin.entities.Company_basic_info;

@Repository("company_basic_infoDao")
public class Company_basic_infoDaoImpl extends BaseDao implements Company_basic_infoDao{
	
	public static final String CTEL = "ctel";
	public static final String CINDUSTRY = "cindustry";

	
	@Override
	public void save(Company_basic_info transientInstance) {
		add(transientInstance);
		
	}

	@Override
	public void delete(Company_basic_info persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public Company_basic_info findById(String id) {
		return (Company_basic_info) getById(Company_basic_info.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Company_basic_info.class, propertyName, value);
	}

	@Override
	public void attachDirty(Company_basic_info instance) {
		merge(instance);
	}

	//ͨ���绰������ҹ�˾������Ϣ
	@Override
	public List findByCtel(String ctel) {
		return findByProperty(CTEL, ctel);
	}
	
	//������ҵ��˾����
		@Override
		public Long findBySindustry(String industry) {
			String hql = "SELECT COUNT(*) from Company_basic_info where cindustry = ?";
			return (Long) getSession().createQuery(hql).setParameter(0, industry).uniqueResult();			
		}
	
	//�������й�˾����
		public Long findAll(){
			String hql = "SELECT COUNT(*) from Company_basic_info";
			return (Long) getSession().createQuery(hql).uniqueResult();
		}
	

}
