package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.MessageDao;
import com.lijin.entities.Message;

@Repository
public class MessageDaoimpl extends BaseDao implements MessageDao{
	public static final String RECEIVER = "receiver";
	public static final String SENDER = "sender";
	
	
	@Override
	public void save(Message transientInstance) {
		add(transientInstance);
		
	}
	@Override
	public void delete(Message persistentInstance) {
		delete1(persistentInstance);
		
	}
	@Override
	public Message findById(String id) {
		return (Message) getById(Message.class,id);
	}
	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Message.class, propertyName, value);
	}
	@Override
	public void attachDirty(Message instance) {
		merge(instance);
		
	}
	
	//���ݽ������ҵ�ϵͳ��Ϣ
	@Override
	public List findByReceiver(Object receiver) {
		return findByProperty(RECEIVER, receiver);
	}
	
	//���ݷ������ҵ�ϵͳ��Ϣ
	@Override
	public List findBySender(Object sender) {
		return findByProperty(SENDER, sender); 
	}
	
	


}
