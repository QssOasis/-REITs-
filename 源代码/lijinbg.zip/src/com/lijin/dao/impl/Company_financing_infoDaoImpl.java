package com.lijin.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lijin.common.BaseDao;
import com.lijin.dao.Company_financing_infoDao;
import com.lijin.entities.Company_basic_info;
import com.lijin.entities.Company_financing_info;

@Repository("company_financing_infoDao")
public class Company_financing_infoDaoImpl extends BaseDao implements Company_financing_infoDao {

	private static final String COMPANY_BASIC_INFO = "company_basic_info";
	

	@Override
	public void save(Company_financing_info transientInstance){
		add(transientInstance);
		
	}

	@Override
	public void delete(Company_financing_info persistentInstance) {
		delete1(persistentInstance);
		
	}

	@Override
	public Company_financing_info findById(String id) {
			return (Company_financing_info) getById(Company_financing_info.class, id);
	}

	@Override
	public List findByProperty(String propertyName, Object value) {
		return findByProperty(Company_financing_info.class, propertyName, value);
	}

	@Override
	public void attachDirty(Company_financing_info instance) {
		merge(instance);
		
	}

	//ͨ����˾������Ϣ���ҹ�˾������Ϣ
	@Override
	public List findByCompany_basic_info(Company_basic_info company_basic_info) {
		String hql = "from Company_financing_info where company_basic_info = ? order by cfiApplydate desc";
		return getSession().createQuery(hql).setParameter(0, company_basic_info).list();
	}
	
	//ͨ����˾������Ϣ������ҵ��ǰ������Ϣ
	public List findCurrentCompany_financing_info(Company_basic_info company_basic_info){
		String hql = "from Company_financing_info where company_basic_info = ? and statement != 7  and  statement != 8 and statement !=6";
		return getSession().createQuery(hql).setParameter(0, company_basic_info).list();
	}

	//ͨ����˾������Ϣ������ҵ��ʷ������Ϣ
	@Override
	public List findHistoryCompany_financing_info(Company_basic_info company_basic_info) {
		String hql = "from Company_financing_info where company_basic_info = ? and  (statement = 7 or statement = 8 or statement =6)";
		return getSession().createQuery(hql).setParameter(0, company_basic_info).list();
	}
	
	//���������Ѿ����Ŵ������ҵ��
	@Override
	public List findALLActive(){
		String hql = "select cfi.financingAmount from Company_financing_info cfi where statement = 6 or statement = 7";
		return getSession().createQuery(hql).list();
	}
	
	

	//δ��˹�˾��Ϣ
	@Override
	public List uncheckedCorpsAsset() {
		String hql = "from Company_financing_info where statement = 1 ";
		return getSession().createQuery(hql).list();
	}
	
	@Override
	//���¹�˾״̬Ϊ3
	public void  updateCorpState3(String cfiid){
		String hql="update Company_financing_info set statement=? where cfiid=?";
		getCurrentsession().createQuery(hql).setInteger(0, 3).setString(0, cfiid);
		
	}

	@Override
	public void updateCorpState2(String cfiid) {
		String hql="update Company_financing_info set statement=? where cfiid=?";
		getCurrentsession().createQuery(hql).setInteger(0, 2).setString(0, cfiid);
		
	}

	@Override
	public List checkedCorpsAsset() {
		String hql = "from Company_financing_info where statement = 2 ";
		return getSession().createQuery(hql).list();
	};

}
