package com.lijin.dao;

import java.util.List;

import com.lijin.entities.User_own_bond;

public interface User_own_bondDao {
	
	void save(User_own_bond transientInstance);
	
	void delete(User_own_bond persistentInstance);
	
	User_own_bond findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	List findByProperty(String propertyName1, String propertyName2, Object value1, Object value2);
	
	List showUserOwnBond(Object owner , int index);
	
	void attachDirty(User_own_bond instance);
	
	List showUserSoldBond(Object owner , int index);
	
	List getUserBond(Object owner , Object bond);
	

}