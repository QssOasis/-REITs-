package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Company_financing_money;

public interface Company_financing_moneyDao {
	
	void save(Company_financing_money transientInstance);
	
	void delete(Company_financing_money persistentInstance); 
	
	Company_financing_money findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Company_financing_money instance);
	
}