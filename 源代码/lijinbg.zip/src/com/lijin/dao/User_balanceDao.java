package com.lijin.dao;

import java.util.List;

import com.lijin.entities.User_balance;

public interface User_balanceDao {

	void save(User_balance transientInstance);
	
	void delete(User_balance persistentInstance); 
	
	User_balance findById(String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(User_balance instance);
	
	
}