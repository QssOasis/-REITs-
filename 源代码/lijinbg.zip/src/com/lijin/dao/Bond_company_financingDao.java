package com.lijin.dao;

import java.util.List;

import com.lijin.entities.Bond;
import com.lijin.entities.Bond_company_financing;
import com.lijin.entities.Company_financing_info;

public interface Bond_company_financingDao {
	
	void save(Bond_company_financing transientInstance);
	
	void delete(Bond_company_financing persistentInstance); 
	
	Bond_company_financing findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(Bond_company_financing instance);
	
	List findByBond(Bond bond);
	
	List findByCompany_financing_info(Company_financing_info company_financing_info);
	
}
