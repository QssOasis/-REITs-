package com.lijin.dao;

import java.util.Date;
import java.util.List;

import com.lijin.entities.User_trade_bond;

public interface User_trade_bondDao {
	
	void save(User_trade_bond transientInstance);
	
	void delete(User_trade_bond persistentInstance);
	
	User_trade_bond findById(java.lang.String id);
	
	List findByProperty(String propertyName, Object value);
	
	void attachDirty(User_trade_bond instance);
	
	List seekqingcangbuyUser_trade_bond(Object user,Object bond,Object begin , Object end);
	
	List seekqingcangsellUser_trade_bond(Object user,Object bond,Object begin , Object end);
	
	List showDealBond(Object user , Date begin , Date end ,int index);	
	
	List showUserbought1Bond(Object owner , Integer type ,int index);
	
	
}
