package com.lijin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lijin.dao.BondDao;
import com.lijin.dao.Bond_company_financingDao;
import com.lijin.dao.MessageDao;
import com.lijin.dao.User_balanceDao;
import com.lijin.dao.User_basic_infoDao;
import com.lijin.dao.User_or_com_bankDao;
import com.lijin.entities.Bond;
import com.lijin.entities.User_basic_info;
import com.lijin.entities.User_or_com_bank;
import com.lijin.utils.DbContextHolder;

@Repository
public class InvestorInfoService {
	@Autowired
	private User_balanceDao user_balanceDao;
	@Autowired
	private BondDao bondDao;
	@Autowired
	private MessageDao messageDao;
	@Autowired
	private User_basic_infoDao user_basic_infoDao;

	
	@Autowired
	private Bond_company_financingDao bond_company_financingDao;
	
	@Autowired
	private User_or_com_bankDao user_or_com_bankDao;

	public Double findBalance(String id){
		DbContextHolder.setDbType("1");
		Double balance=user_balanceDao.findById(id).getBalance();
		System.out.println(id);

		DbContextHolder.clearDbType();
		
		return balance;
	}
	public List seekByUser2(Integer level,String bid ,int index){
		
		return bondDao.seekByUser2(level, bid, index);
	}
	public Bond findById(String id){
		return bondDao.findById(id);
	}
	
	public List findMessage(Object receiver){
		List list=messageDao.findByReceiver(receiver);
		return list;
	}
	public List findByUtel(Object utel) {
		
		return user_basic_infoDao.findByUtel(utel);
	}
	public void save(User_basic_info transientInstance) {
		user_basic_infoDao.save(transientInstance);
		
	}
	public Bond findBond(String bid){
		return bondDao.findById(bid);
	}
	

	
	public List<User_or_com_bank> findBank(User_basic_info user_basic_info){
		return user_or_com_bankDao.findByUser(user_basic_info);
	}
	public void deleteCard(String id){
		User_or_com_bank user_or_com_bank=user_or_com_bankDao.findById(id);
		user_or_com_bankDao.delete(user_or_com_bank);
	}
	

}
