package com.lijin.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lijin.dao.Bond_company_financingDao;
import com.lijin.dao.Company_financing_infoDao;
import com.lijin.dao.Company_financing_moneyDao;
import com.lijin.entities.Bond;
import com.lijin.entities.Bond_company_financing;
import com.lijin.entities.Company_basic_info;
import com.lijin.entities.Company_financing_info;

@Repository
public class CompanyService {
	@Autowired
	private Company_financing_infoDao company_financing_infoDao;

	@Autowired
	private Bond_company_financingDao bond_company_financingDao;

	@Autowired
	private Company_financing_moneyDao company_financing_moneyDao;

	public List findCurrentCompany_financing_info(Company_basic_info company_basic_info) {
		List cuList = company_financing_infoDao.findCurrentCompany_financing_info(company_basic_info);
		for (int i = 0; i < cuList.size(); i++) {
			Company_financing_info company_financing_info = (Company_financing_info) cuList.get(i);
			System.out.println("findCurrentCompany");
			System.out.println(company_financing_info);
			List bondL = bond_company_financingDao.findByCompany_financing_info(company_financing_info);
			System.out.println("bondList");

			System.out.println(bondL);
		}

		return company_financing_infoDao.findCurrentCompany_financing_info(company_basic_info);
	}

	// ���ݹ�˾��ѯ��Ӧ��������Ϣ
	public List findHistoryfinancinginfo(Company_basic_info company_basic_info) {
		List<Company_financing_info> list = company_financing_infoDao
				.findHistoryCompany_financing_info(company_basic_info);

		List<Bond_company_financing> list2;
		Bond bond;
		List<Bond> bonds = new ArrayList<>();
		List<Object[]> list3 = new ArrayList<Object[]>();
		int i, k;
		String cfiid;
		Object[] object = null;
		for (Company_financing_info company_financing_info : list) {
			
			object = new Object[9];
			cfiid = company_financing_info.getCfiid();
			Double loanrate = company_financing_moneyDao.findById(cfiid).getLoanRate();

			
	
			
			list2 = bond_company_financingDao.findByCompany_financing_info(company_financing_info);
			i = bonds.size();
			/**��Ҫ�޸�����
			for (Bond_company_financing bond_company_financing : list2) {
				bond = bond_company_financing.getBond();
				bonds.add(bond);
			}
			*/
			k = bonds.size();
		

			// ������Ҫ����Ϣ���ϵ�object���棬����ҪҪ���ص�list3������
			object[0] = cfiid;
			object[1] = company_financing_info.getCfiApplydate();
			object[2] = company_financing_info.getCfiGetMoneyDate();
			object[3] = company_financing_info.getFinancingProjectName();
			object[4] = company_financing_info.getFinancingAmount();
			object[5] = company_financing_info.getFinancingDeadline();
			object[6] = loanrate;
			object[7] = company_financing_info.getStatement();// 6��δ����7���ѻ���8��ʧ��)
			List l = bonds.subList(i, k);
			String bnames = "";
			for (int m = 0; m < l.size(); m++) {
				Bond b = (Bond) (l.get(m));
				bnames += b.getBname();
				bnames += "\t";
			}
			object[8] = bnames;
			list3.add(object);
		}
		return list3;
	}

	public List find(Company_basic_info company_basic_info) {
		return company_financing_infoDao.findByCompany_basic_info(company_basic_info);
	}
}
