package com.lijin.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lijin.dao.BondDao;
import com.lijin.dao.User_collect_bondDao;
import com.lijin.dao.User_own_bondDao;
import com.lijin.dao.User_trade_bondDao;
import com.lijin.entities.Bond;
import com.lijin.entities.User_basic_info;
import com.lijin.entities.User_collect_bond;
import com.lijin.entities.User_own_bond;
import com.lijin.entities.User_trade_bond;
import com.lijin.utils.DateUtils;
import com.lijin.utils.Show2Bondinfo;

@Repository
public class Investor1stMarketService {
	@Autowired
	private BondDao bondDao;
	@Autowired
	private User_trade_bondDao user_trade_bondDao;
	
	@Autowired
	private User_collect_bondDao user_collect_bondDao;
	@Autowired
	private User_own_bondDao user_own_bondDao;
	public List bond1listbytime(){
		return bondDao.bond1listbytime();
	}
	public List findBonds(Integer bstatement, String orderPropertyName, int pageSize){
		return bondDao.findBonds(bstatement, orderPropertyName, pageSize);
	}
	public List showUserbought1Bond(Object owner , Integer type ,int index){
		List list2=new ArrayList<>();
		List list=user_trade_bondDao.showUserbought1Bond(owner, type, index);
		Object[] objects=null;
		for(int i=0;i<list.size();i++){
			objects=new Object[8];
			User_trade_bond user_trade_bond=(User_trade_bond)list.get(i);
			
			objects[2]=user_trade_bond.getUtbturnover();
			objects[3]=user_trade_bond.getUtbprice();
			objects[4]=user_trade_bond.getUtbdate();
			objects[5]=user_trade_bond.getUtbid();
			objects[6]=user_trade_bond.getStatement();
			objects[7]=user_trade_bond.getFailedResult();
			list2.add(objects);
		}
		return list2;
	}
	
	
	public List marketBondInfo(String bid, Integer level, int index) {
		List<Show2Bondinfo> list1 = new ArrayList<>();
		
		List<Bond> list2 = bondDao.seekByUser2(level, bid, index);
		
		for(Bond bond: list2){
			Show2Bondinfo show2Bondinfo = bondTradeAllInfo(bond);
			list1.add(show2Bondinfo);
		}
		
		return list1;
	}
	private Show2Bondinfo bondTradeAllInfo(Bond bond) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List followBond(User_basic_info user_basic_info) {
		List<Show2Bondinfo> list1 = new ArrayList<>();
		
		List<User_collect_bond> list2 = user_collect_bondDao.findByOwner(user_basic_info);
		
		
		return list1;
	}
	
	public List dealBond(User_basic_info user_basic_info) {		
		List<User_own_bond> list1 = user_own_bondDao.showUserOwnBond(user_basic_info, 1);
		List<Object[]> list2 = new ArrayList<>();
		Object[] object = null;
		
		for(User_own_bond user_own_bond : list1){
			object = new Object[8];
			object[0]=user_own_bond.getUobid();
			object[1]=user_own_bond.getBid();
			object[3]=user_own_bond.getUobturnover();
			object[4]=user_own_bond.getUobprice();
			
			list2.add(object);
		}		
		return list2;
	}
}
