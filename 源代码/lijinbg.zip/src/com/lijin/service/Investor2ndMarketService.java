package com.lijin.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lijin.dao.BondDao;
import com.lijin.dao.User_basic_infoDao;
import com.lijin.dao.User_collect_bondDao;
import com.lijin.dao.User_own_bondDao;
import com.lijin.dao.User_trade_bondDao;
import com.lijin.dao.User_trust_deedDao;
import com.lijin.entities.Bond;
import com.lijin.entities.User_basic_info;
import com.lijin.entities.User_collect_bond;
import com.lijin.entities.User_own_bond;
import com.lijin.entities.User_trade_bond;
import com.lijin.entities.User_trust_deed;
import com.lijin.utils.DateUtil;
import com.lijin.utils.DateUtils;
import com.lijin.utils.DbContextHolder;
import com.lijin.utils.Show2Bondinfo;

@Repository
public class Investor2ndMarketService {
	@Autowired
	private User_trust_deedDao user_trust_deedDao;
	@Autowired 
	private User_trade_bondDao user_trade_bondDao;
	@Autowired
	private BondDao bondDao;
/*
	@Autowired
	private Price_pertimeDao price_pertimeDao;
	@Autowired
	private Price_perdayDao price_perdayDao;
*/
	@Autowired
	private User_collect_bondDao user_collect_bondDao;
	
	@Autowired
	private User_own_bondDao user_own_bondDao;
	@Autowired
	private User_basic_infoDao user_basic_infoDao;
	public List seekBondbuy_5_trust_deeds(Bond bond){//��5��Ϣ
		return user_trust_deedDao.seekBondbuy_5_trust_deeds(bond);
	}
	
	public List seekBondsell_5_trust_deeds(Bond bond){//��5��Ϣ
		return user_trust_deedDao.seekBondsell_5_trust_deeds(bond);
	}
	
	public List<User_trade_bond> showTodayDealBond(Object user  ,int index){//�����û��ɽ���¼
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	     
	    Date start = calendar.getTime();
	 
	    calendar.add(Calendar.DAY_OF_MONTH, 1);
	    calendar.add(Calendar.SECOND, -1);
	     
	    Date end = calendar.getTime();
	   // SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return user_trade_bondDao.showDealBond(user, start, end, index);
	}
	
	public List<User_trade_bond> showHistoryDealBond(Object user ,int index){//��ʷ�û��ɽ���¼
		DateUtil dateUtil=new DateUtil();
		Date[] outs=dateUtil.getMonthCalendar(2016, 8);
		Date[] outs2=dateUtil.getMonthCalendar(2016, 1);
		Date end=outs[1];
		Date start=outs2[0];
		return user_trade_bondDao.showDealBond(user, start, end, index);
	}
	public List bond2new5() {
		List<Show2Bondinfo> list1 = new ArrayList<>();
		
		List<Bond> list2 = bondDao.bond2listbytime(5);
		
		for(Bond bond: list2){
			Show2Bondinfo show2Bondinfo = bond2new5allinfo(bond);
			list1.add(show2Bondinfo);
		}
		return list1;
	}
	protected  Show2Bondinfo bond2new5allinfo(Bond bond) {
		Show2Bondinfo bond2info = new Show2Bondinfo();
		bond2info.setBid(bond.getBid());
		bond2info.setBname(bond.getBname());
		bond2info.setTotalturnover(bond.getTotalTurnover());
		bond2info.setLevel(bond.getLevel());
		bond2info.setAnnualInterestRate(bond.getAnnualInterestRate());
		
		int deadline = bond.getDeadline();
		Date date = new Date();
		Date date1 = bond.getReleaseStartTime();
		Long a = date1.getTime()-date.getTime();
		int b = (int) (a/(1000 * 60 * 60 * 24 * 12));
		bond2info.setShengyuqixian(deadline-b);
		return bond2info;
		
	}
	public List followBonds(User_basic_info user_basic_info) {
		List<Show2Bondinfo> list1 = new ArrayList<>();
		
		List<User_collect_bond> list2 = user_collect_bondDao.findByOwner(user_basic_info);
		
		return list1;
	}
	
	public List dealBonds(User_basic_info user_basic_info) {
		DbContextHolder.setDbType("1");
		List<User_own_bond> list1 = user_own_bondDao.showUserOwnBond(user_basic_info, 1);
		List<Object[]> list2 = new ArrayList<>();
		Object[] object = null;
		
		for(User_own_bond user_own_bond : list1){
			object = new Object[8];
			object[0]=user_own_bond.getUobid();
			
			object[3]=user_own_bond.getUobturnover();
			object[4]=user_own_bond.getUobprice();
			DbContextHolder.setDbType("0");
			
			list2.add(object);
		}		
		return list2;
	}
	
	
	public List withDrawOrders(User_basic_info user_basic_info,Integer type,int index) {
		List<User_trust_deed> list = user_trust_deedDao.showUser_trust_deeds(user_basic_info, type, index);
		List<Object[]> list2 = new ArrayList<>();
		Object[] object = null;
		
		for(User_trust_deed user_trust_deed : list){
			object = new Object[9];
			
			object[2]=user_trust_deed.getUtdprice();
			object[3]=user_trust_deed.getType();
			object[4]=user_trust_deed.getUtdturnover();
			object[5]=user_trust_deed.getPurchasedturnover();
			if(object[5]==null)object[5]=0;
			object[6]=user_trust_deed.getUtdid();
			object[7]=user_trust_deed.getStartDate();
			object[8]=user_trust_deed.getUtdid();
			list2.add(object);		
		}	
		return list2;
	}
	public void deleteOrder(String id){
		user_trust_deedDao.deleteOrders(id);
		
	}
	

	public List clearAccount(User_basic_info user_basic_info , int index) {
		List<User_own_bond> list1 = user_own_bondDao.showUserSoldBond(user_basic_info, index);
		List<Object[]> list2 = new ArrayList<>();
		Object[] object = null;
		System.out.println(list1);
		for(User_own_bond user_own_bond : list1){
			object = new Object[5];
			
			object[1]=user_own_bond.getEnddate();
			object[2]=(user_own_bond.getEnddate().getTime()-user_own_bond.getStartdate().getTime())/(1000*60*60);
			List<User_trade_bond> listmairu  = user_trade_bondDao.seekqingcangbuyUser_trade_bond(user_basic_info,user_own_bond.getBid(),user_own_bond.getStartdate(),user_own_bond.getEnddate());
			List<User_trade_bond> listmaichu  = user_trade_bondDao.seekqingcangsellUser_trade_bond(user_basic_info,user_own_bond.getBid(),user_own_bond.getStartdate(),user_own_bond.getEnddate());			
			Double mairu =0.0;
			Double maichu =0.0;
			for(User_trade_bond user_trade_bond : listmairu){
				mairu = mairu +user_trade_bond.getUtbprice()*user_trade_bond.getUtbturnover();
			}
			for(User_trade_bond user_trade_bond : listmaichu){
				maichu = maichu +user_trade_bond.getUtbprice()*user_trade_bond.getUtbturnover();
			}
			object[3]=maichu-mairu;
			object[4]=(maichu-mairu)/mairu;
			
			list2.add(object);
		}
		return list2;
	}
	
/*
	public Price_pertime findById(String id) {
		return price_pertimeDao.findById(id);
	}
*/
	
	public List findUserOwnBonds(String uid){
		int index=1;
		User_basic_info owner=user_basic_infoDao.findById(uid);
		List list=user_own_bondDao.showUserOwnBond(owner, index);
		List list2=new ArrayList<>();
		Object[] object=null;
		for(int i=0;i<list.size();i++){
			object=new Object[4];
			User_own_bond user_own_bond=(User_own_bond) list.get(i);
			String bname=user_own_bond.getBid();
			Double price2=user_own_bond.getUobprice();
			//Double price=price_pertimeDao.getNewestPrice_pertime(user_own_bond).getPptprice();
			Double price=user_own_bond.getUobprice()+5*Math.random();

			Integer havings=user_own_bond.getUobturnover();
			object[0]=bname;
			object[1]=price2;
			object[2]=price;
			object[3]=havings;
			list2.add(object);
		}
		return list2;
	}

}
