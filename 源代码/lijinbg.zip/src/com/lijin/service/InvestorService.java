package com.lijin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;


import com.lijin.dao.BondDao;
import com.lijin.dao.User_basic_infoDao;
import com.lijin.dao.User_collect_bondDao;
import com.lijin.dao.User_own_bondDao;
import com.lijin.entities.Bond;
import com.lijin.entities.User_basic_info;

@Repository
public class InvestorService {
	@Autowired
	private BondDao bondDao;
	
	@Autowired
	private User_basic_infoDao user_basic_infoDao;	
	@Autowired
	private User_collect_bondDao user_collect_bondDao;
	@Autowired
	private User_own_bondDao user_own_bondDao;
	
	public List bond1listbytime(){
		return bondDao.bond1listbytime();
	}
	public List bond2listbyturnover(){
		return bondDao.bond2listbyturnover();
	}
	
	public List<Bond> bond1listbyturnover(int pageSize){
		return bondDao.bond1listbyturnover(pageSize);
	}
	
	public Bond findById(String bid) {
		return bondDao.findById(bid);
	}
	
	public List<Bond> bond2listbytime(int pageSize){
		return bondDao.bond2listbytime(pageSize);
	}
	
	public void save(User_basic_info transientInstance) {
		user_basic_infoDao.save(transientInstance);
	}
	public List<User_basic_info> findByUtel(Object utel){
		return user_basic_infoDao.findByUtel(utel);
	}
	public List<Bond> seekByUser1(Integer level,String bid , int index){
		level=null;
		bid="";
		index=1;
		return bondDao.seekByUser1(level, bid, index);
	}

	public List<Bond> seekByUser2(Integer level,String bid ,int index ){
		return bondDao.seekByUser2(level, bid, index);
	}
	public List findByOwner(Object owner){
		return user_collect_bondDao.findByOwner(owner);
	}
	
	public List findBonds(Integer bstatement, String orderPropertyName, int pageSize) {
		return bondDao.findBonds(bstatement, orderPropertyName, pageSize);
	}


	}

