package com.lijin.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lijin.dao.BondDao;
import com.lijin.dao.Company_basic_infoDao;
import com.lijin.dao.Spv_basic_infoDao;
import com.lijin.dao.User_basic_infoDao;
import com.lijin.entities.Bond;
import com.lijin.utils.Show2Bondinfo;

@Repository
public class LoginService {
	
	@Autowired
	private User_basic_infoDao user_basic_infoDao;
	@Autowired
	private Company_basic_infoDao company_basic_infoDao;
	@Autowired 
	private Spv_basic_infoDao spv_basic_infoDao; 
	@Autowired
	private BondDao bondDao;
	
	
	public List login(String utel){
		List list1=user_basic_infoDao.findByUtel(utel);
		List list2=company_basic_infoDao.findByCtel(utel);
		List list3=spv_basic_infoDao.findByTel(utel);
		if (list1.size()!=0&&list1!=null){
			return list1;
		}
		if(list2.size()!=0&& list2!=null){
			return list2;
		}
		if(list3.size()!=0&& list3!=null){
			return list3;
		}
		return null;
	}
	
	public List bond1listbytime(){
		return bondDao.bond1listbytime();
	}


	public List bond2new5() {
		List<Show2Bondinfo> list1 = new ArrayList<>();
		
		List<Bond> list2 = bondDao.bond2listbytime(5);
		
		for(Bond bond: list2){
			Show2Bondinfo show2Bondinfo = bond2new5allinfo(bond);
			list1.add(show2Bondinfo);
		}
		return list1;
	}
	
	protected  Show2Bondinfo bond2new5allinfo(Bond bond) {
		Show2Bondinfo bond2info = new Show2Bondinfo();
		bond2info.setBid(bond.getBid());
		bond2info.setBname(bond.getBname());
		bond2info.setTotalturnover(bond.getTotalTurnover());
		bond2info.setLevel(bond.getLevel());
		bond2info.setAnnualInterestRate(bond.getAnnualInterestRate());
		
		
		int deadline = bond.getDeadline();
		Date date = new Date();
		Date date1 = bond.getReleaseStartTime();
		Long a = date1.getTime()-date.getTime();
		int b = (int) (a/(1000 * 60 * 60 * 24 * 12));
		bond2info.setShengyuqixian(deadline-b);
		return bond2info;
	}
	
	
	

}
